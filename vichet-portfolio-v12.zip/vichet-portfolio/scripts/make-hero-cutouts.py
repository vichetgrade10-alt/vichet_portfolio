"""
Cuts the hero portrait (and the Spider-Man reveal photo) out of their grey studio backdrop and saves
transparent WebPs.

    pip install opencv-contrib-python-headless numpy
    python3 scripts/make-hero-cutouts.py

It models the backdrop as a smooth gradient, seeds GrabCut with "certainly wall" / "certainly body",
then refines the edge with a guided filter so hair and shirt edges stay soft instead of jagged.
"""
import cv2
import numpy as np

W, H = 800, 1200  # hero portrait frame (2:3)


def cutout(src, seeds):
    """Returns a BGRA array: the photo with its plain studio backdrop made transparent."""
    img = cv2.imread(src)
    H, W = img.shape[:2]

    # 1. model the wall as a smooth cubic surface fitted to the border strips
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB).astype(np.float32)
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    xn, yn = xx / W - .5, yy / H - .5
    terms = np.stack([np.ones_like(xn), xn, yn, xn * xn, xn * yn, yn * yn, xn**3, yn**3,
                      xn * xn * yn, xn * yn * yn], -1)
    known = (xx < seeds["wall_x"][0]) | (xx > seeds["wall_x"][1]) | (yy < seeds["wall_y"])
    A = terms[known][::5]
    pred = np.zeros_like(lab)
    resid = []
    for c in range(3):
        coef, *_ = np.linalg.lstsq(A, lab[..., c][known][::5], rcond=None)
        pred[..., c] = terms @ coef
        resid.append((lab[..., c] - pred[..., c])[known].std())
    dist = np.sqrt((((lab - pred) / np.maximum(np.array(resid), 2.5)) ** 2).sum(2))

    # 2. seed GrabCut
    mask = np.full((H, W), cv2.GC_PR_BGD, np.uint8)
    mask[dist > 3.5] = cv2.GC_PR_FGD
    mask[dist < 1.6] = cv2.GC_BGD
    mask[: seeds["wall_y"], :] = cv2.GC_BGD
    mask[:, : seeds["wall_x"][0]] = cv2.GC_BGD
    mask[:, seeds["wall_x"][1]:] = cv2.GC_BGD
    core = np.zeros((H, W), np.uint8)
    for kind, *a in seeds["core"]:
        if kind == "ellipse":
            cv2.ellipse(core, (int(a[0]), int(a[1])), (int(a[2]), int(a[3])), 0, 0, 360, 255, -1)
        else:
            cv2.rectangle(core, (int(a[0]), int(a[1])), (int(a[2]), int(a[3])), 255, -1)
    mask[core > 0] = cv2.GC_FGD
    bgd = np.zeros((1, 65))
    fgd = np.zeros((1, 65))
    cv2.grabCut(img, mask, None, bgd, fgd, 8, cv2.GC_INIT_WITH_MASK)
    fg = np.where((mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD), 255, 0).astype(np.uint8)

    # 3. clean up: biggest blob, fill small holes, smooth
    n, lbl, stats, _ = cv2.connectedComponentsWithStats(fg)
    fg = np.where(lbl == 1 + np.argmax(stats[1:, cv2.CC_STAT_AREA]), 255, 0).astype(np.uint8)
    n, lbl, stats, _ = cv2.connectedComponentsWithStats(255 - fg)
    for i in range(1, n):
        x, y, ww, hh, a = stats[i]
        if a < 9000 and not (x == 0 or y == 0 or x + ww == W):
            fg[lbl == i] = 255
    fg = cv2.morphologyEx(fg, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)))
    fg = cv2.morphologyEx(fg, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7)))
    fg = cv2.erode(fg, np.ones((3, 3), np.uint8), iterations=1)       # drop the grey halo

    # 4. soft, edge-aware alpha: guided filter follows the real image edges (hair strands, collar)
    soft = cv2.GaussianBlur(fg, (0, 0), 2.0).astype(np.float32) / 255
    guide = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255
    alpha = cv2.ximgproc.guidedFilter(guide, soft, 6, 1e-4)
    alpha = np.nan_to_num(alpha, nan=0.0)
    alpha = np.clip((alpha - 0.12) / 0.76, 0, 1)                    # tighten the matte a touch
    alpha[fg == 0] *= np.clip(cv2.GaussianBlur(fg, (0, 0), 3).astype(np.float32) / 255 * 2, 0, 1)[fg == 0]

    # 5. de-spill: pull the wall's grey out of semi-transparent edge pixels
    rgb = img.astype(np.float32)
    wall = np.clip(cv2.cvtColor(pred.astype(np.uint8), cv2.COLOR_LAB2BGR).astype(np.float32), 0, 255)
    a3 = alpha[..., None]
    edge = (a3 > 0.02) & (a3 < 0.98)
    fixed = (rgb - wall * (1 - a3)) / np.maximum(a3, 0.35)
    rgb = np.where(edge, np.clip(fixed, 0, 255), rgb)

    rgba = np.dstack([rgb.astype(np.uint8), (alpha * 255).astype(np.uint8)])
    print("cut out", src, "wall residual", np.round(resid, 2))
    return rgba



def bbox(rgba, min_alpha=128):
    ys, xs = np.where(rgba[..., 3] >= min_alpha)
    return xs.min(), xs.max(), ys.min(), ys.max()


def save(rgba, out_file):
    cv2.imwrite(out_file, rgba, [cv2.IMWRITE_WEBP_QUALITY, 92])
    print("wrote", out_file)


# --- 1. you: new photo (1280x1196, grey backdrop) -> transparent cut-out ---
me = cutout(
    "src/assets/source/portrait-me-v2-original.jpg",
    dict(wall_x=(250, 1030), wall_y=90, core=[
        ("ellipse", 645, 330, 85, 110), ("ellipse", 647, 195, 105, 55),
        ("rect", 480, 540, 820, 1195),
    ]),
)
mx0, mx1, my0, my1 = bbox(me)
print("person bbox", mx0, mx1, my0, my1)

# crop to the 2:3 hero frame, centred on the person, full height of the photo
ph, pw = me.shape[:2]
crop_w = round(ph * W / H)
cx = (mx0 + mx1) // 2
x0 = int(np.clip(cx - crop_w // 2, 0, pw - crop_w))
me_frame = cv2.resize(me[:, x0:x0 + crop_w], (W, H), interpolation=cv2.INTER_AREA)
save(me_frame, "src/assets/portrait-me.webp")

# --- 2. Spider-Man: cut out, then scale/shift so his head and shoulders land on yours ---
sp = cutout(
    "src/assets/source/portrait-spider-original.webp",
    dict(wall_x=(110, 700), wall_y=150, core=[
        ("ellipse", 400, 340, 80, 110), ("rect", 300, 560, 520, 1199),
    ]),
)
fx0, fx1, fy0, _ = bbox(me_frame)
sx0, sx1, sy0, _ = bbox(sp)
scale = (fx1 - fx0) / (sx1 - sx0)           # match shoulder / arm width
M = np.float32([
    [scale, 0, (fx0 + fx1) / 2 - scale * (sx0 + sx1) / 2],   # same centre line
    [0, scale, fy0 - scale * sy0],                            # same head top
])
sp_frame = cv2.warpAffine(sp, M, (W, H), flags=cv2.INTER_AREA if scale < 1 else cv2.INTER_CUBIC,
                          borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0, 0))
print("spider scale", round(scale, 3))
save(sp_frame, "src/assets/portrait-spider.webp")
