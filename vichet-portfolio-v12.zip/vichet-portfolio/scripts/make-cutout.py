"""
Cuts a person out of a plain studio backdrop and saves a transparent WebP for the hero / About photo.

    pip install opencv-python-headless numpy
    python3 scripts/make-cutout.py src/assets/source/vichet-original.jpg src/assets/vichet-cutout.webp

Works best with a plain, evenly lit backdrop (like the original photo). It models the wall as a smooth
gradient, then uses GrabCut to separate the person from it. It also prints where the head is, so the
circle behind the head in Hero.module.css (--head-x / --head-y / --head-d) can be matched to a new photo.
"""
import sys
import numpy as np
import cv2

src, out_file = sys.argv[1], sys.argv[2]
img = cv2.imread(src); h, w = img.shape[:2]; print("size", w, h)

# --- 1. model the studio wall as a smooth gradient (it is darker near the subject: vignette) ---
lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB).astype(np.float32)
yy, xx = np.mgrid[0:h, 0:w].astype(np.float32); xn = xx / w - .5; yn = yy / h - .5
terms = np.stack([np.ones_like(xn), xn, yn, xn*xn, xn*yn, yn*yn, xn**3, yn**3, xn*xn*yn, xn*yn*yn], -1)   # cubic surface
known = (xx < 125) | (xx > 605) | (yy < 70)                      # border strips that are certainly wall
A = terms[known][::7]; pred = np.zeros_like(lab); resid = []
for c in range(3):
    coef, *_ = np.linalg.lstsq(A, lab[..., c][known][::7], rcond=None)
    pred[..., c] = terms @ coef
    resid.append((lab[..., c] - pred[..., c])[known].std())
dist = np.sqrt((((lab - pred) / np.maximum(np.array(resid), 2.5)) ** 2).sum(2))
print("wall residual std", np.round(resid, 2))

# --- 2. seed GrabCut: obvious wall = background, obvious body core = foreground ---
mask = np.full((h, w), cv2.GC_PR_BGD, np.uint8)
mask[dist > 3.5] = cv2.GC_PR_FGD
mask[dist < 1.6] = cv2.GC_BGD
mask[:70, :] = cv2.GC_BGD; mask[:, :30] = cv2.GC_BGD; mask[:, -30:] = cv2.GC_BGD
core = np.zeros((h, w), np.uint8)
cv2.ellipse(core, (int(w*.5), int(h*.27)), (int(w*.075), int(h*.095)), 0, 0, 360, 255, -1)    # face
cv2.ellipse(core, (int(w*.5), int(h*.165)), (int(w*.10), int(h*.055)), 0, 0, 360, 255, -1)    # hair
cv2.rectangle(core, (int(w*.32), int(h*.47)), (int(w*.68), h-1), 255, -1)                      # torso
mask[core > 0] = cv2.GC_FGD
bgd = np.zeros((1,65)); fgd = np.zeros((1,65))
cv2.grabCut(img, mask, None, bgd, fgd, 8, cv2.GC_INIT_WITH_MASK)
fg = np.where((mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD), 255, 0).astype(np.uint8)

# --- 3. clean up: keep the biggest blob, fill holes, smooth the edge ---
n, lbl, stats, _ = cv2.connectedComponentsWithStats(fg)
big = 1 + np.argmax(stats[1:, cv2.CC_STAT_AREA]); fg = np.where(lbl == big, 255, 0).astype(np.uint8)
inv = 255 - fg; n, lbl, stats, _ = cv2.connectedComponentsWithStats(inv)
for i in range(1, n):
    x, y, ww, hh, a = stats[i]
    if x > 0 and y > 0 and x + ww < w and y + hh < h and a < 6000: fg[lbl == i] = 255      # small holes inside the body
fg = cv2.morphologyEx(fg, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5,5)))
fg = cv2.erode(fg, np.ones((3,3), np.uint8), iterations=2)                                    # pull the edge in to drop the grey halo
alpha = cv2.GaussianBlur(fg, (0,0), 1.1)
rgba = np.dstack([img, alpha])
cv2.imwrite(out_file, rgba, [cv2.IMWRITE_WEBP_QUALITY, 92])

# --- 4. where is the head? (hair top -> chin, measured on the mask) ---
ys, xs = np.where(fg > 0)
top = int(ys.min())
widths = [(y, np.where(fg[y] > 0)[0]) for y in range(top, top + int(h * .45))]
neck = min(widths[int(h*.18):], key=lambda t: len(t[1]) and (t[1].max() - t[1].min()))   # narrowest row below the ears = neck
chin = neck[0]
ear_row = top + int((chin - top) * .55)
cols = np.where(fg[ear_row] > 0)[0]
cx, cy = (cols.min() + cols.max()) / 2, (top + chin) / 2
print(f"head: centre ({cx:.0f}, {cy:.0f})px, height {chin - top}px, width {cols.max() - cols.min()}px  (image {w}x{h})")
print(f"CSS: --head-x: {100*cx/w:.1f}%; --head-y: {100*cy/h:.1f}%; head height = {100*(chin-top)/w:.1f}% of image width")
