"""
Rebuilds the two JSON files the EV dashboard reads, straight from the Power BI report (or a CSV).

    python3 scripts/export-ev-data.py path/to/EV_Adoption.pbix
    python3 scripts/export-ev-data.py path/to/train.csv

Writes:
    src/data/ev/evSales.json    one object per sales record (the dashboard filters these in the browser)
    src/data/ev/evSummary.json  headline numbers + monthly revenue for the project card

Needs pandas, plus pbixray for .pbix files:  pip install pandas pbixray
The data is the "train" table of EV_Adoption.pbix.
"""
import json
import sys
from pathlib import Path

import pandas as pd

if len(sys.argv) != 2:
    sys.exit(__doc__)

out_dir = Path(__file__).resolve().parent.parent / "src" / "data" / "ev"
source = Path(sys.argv[1])
if source.suffix.lower() == ".pbix":
    from pbixray import PBIXRay  # reads the data model stored inside the .pbix

    df = PBIXRay(str(source)).get_table("train")
    df["Date"] = pd.to_datetime(df["Date"])
else:
    df = pd.read_csv(source, parse_dates=["Date"])

# 1) raw rows - monthly data, so "2023-06" is enough. "Revenue Fast Charging" was a derived Power BI column.
columns = ["Date", "Region", "Brand", "Model", "Vehicle_Type", "Battery_Capacity_kWh",
           "Discount_Percentage", "Customer_Segment", "Fast_Charging_Option", "Units_Sold", "Revenue"]
rows = df[columns].copy()
rows["Date"] = rows["Date"].dt.strftime("%Y-%m")
# plain Python types so the JSON is identical whichever source was used
for col in ["Battery_Capacity_kWh", "Discount_Percentage", "Units_Sold", "Revenue"]:
    rows[col] = rows[col].astype("int64")
for col in ["Region", "Brand", "Model", "Vehicle_Type", "Customer_Segment", "Fast_Charging_Option"]:
    rows[col] = rows[col].astype(object)
(out_dir / "evSales.json").write_text(json.dumps(rows.to_dict(orient="records"), separators=(",", ":")))

# 2) summary used by the project card
by_model = df.groupby("Model").Units_Sold.sum().sort_values(ascending=False)
monthly = df.groupby(df.Date.dt.month).Revenue.sum().reindex(range(1, 13))
summary = {
    "records": int(len(df)),
    "regions": int(df.Region.nunique()),
    "brands": int(df.Brand.nunique()),
    "revenue": int(df.Revenue.sum()),
    "units": int(df.Units_Sold.sum()),
    "avgDiscount": round(float(df.Discount_Percentage.mean()), 2),
    "revenuePerUnit": round(float(df.Revenue.sum() / df.Units_Sold.sum()), 2),
    "topModel": by_model.index[0],
    "topModelUnits": int(by_model.iloc[0]),
    "monthlyRevenue": [int(x) for x in monthly],
}
(out_dir / "evSummary.json").write_text(json.dumps(summary, indent=2))
print(f"Wrote {len(rows)} rows to {out_dir}")
