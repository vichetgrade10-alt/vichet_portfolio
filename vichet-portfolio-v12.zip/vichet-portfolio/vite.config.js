import { fileURLToPath, URL } from 'node:url'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
  build: {
    // The dashboard + chart library load on demand (see Projects.jsx), so a larger chunk is fine.
    chunkSizeWarningLimit: 700,
  },
  css: {
    modules: { localsConvention: 'camelCaseOnly' },
  },
})
