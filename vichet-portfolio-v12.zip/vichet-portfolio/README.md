# Vichet Out · Portfolio

A React + Vite portfolio with a red / navy web-slinger theme: cut-out hero portrait with parallax, scrolling ribbons,
a connected-web skills map, an interactive EV sales dashboard (rebuilt from a Power BI report), a one-time animated intro, an interactive hero web that stretches toward your cursor, a spider mascot with tracking eyes that follows your scroll, click-to-shoot web bursts, self-drawing web
dividers, tilt project cards, light/dark mode and a fully responsive layout.

## Quick start

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # production build in /dist
npm run preview    # serve the production build locally
npm run lint       # ESLint
npm run format     # Prettier
```

## Edit your content

You only need the files in **`src/data/`**:

| File            | What it controls                                                             |
| --------------- | ---------------------------------------------------------------------------- |
| `profile.js`    | Name, intro, rotating roles, ribbons, about text, email, social links        |
| `skills.js`     | Skill names, notes and `level` (1-100 → bar width + Advanced/Expert label)   |
| `projects.js`   | Project cards (`link` opens a site, `dashboard` opens the live dashboard)    |
| `ev/`           | EV dashboard data: `evSales.json` (rows) and `evSummary.json` (project card) |
| `navigation.js` | Navbar links                                                                 |

Your photo is a transparent cut-out, `src/assets/vichet-cutout.webp`. To use another photo: `python3 scripts/make-cutout.py photo.jpg src/assets/vichet-cutout.webp` (plain background works best), then set `--head-x/--head-y/--head-d` in `Hero.module.css` to the values it prints.

The hero portrait and its Spider-Man twin are transparent cut-outs too (`portrait-me.webp`, `portrait-spider.webp`). To change them, drop new photos with a plain backdrop into `src/assets/source/`, point `scripts/make-hero-cutouts.py` at them and run `python3 scripts/make-hero-cutouts.py` (needs `opencv-contrib-python-headless` and `numpy`).

The gold lens that follows your cursor (`PortraitReveal.jsx`) is drawn with WebGL: a spring-driven head, a tapering liquid trail and a crisp rim. Tweak `R`, `LIFE`, `STIFFNESS` and `DAMPING` at the top of the file to change its size, trail length and bounciness. Browsers without WebGL automatically use the 2D-canvas version in `PortraitRevealCanvas.jsx`.

> **Tip:** fill in `email` in `profile.js` to switch on the contact form and the "Email me" button.

## Project structure

```
src/
├── main.jsx                  entry point
├── App.jsx                   page composition
├── assets/                   images
├── data/                     all editable content (see above)
├── styles/
│   ├── tokens.css            colours, spacing, radius, motion - the design system
│   └── base.css              reset + element defaults
├── hooks/                    reusable behaviour
│   ├── usePointerParallax.js  eased pointer parallax for the hero layers
│   ├── useInView.js          scroll-triggered reveal
│   ├── useScrollSpy.js       highlights the active nav link
│   ├── useScrollEffects.js   one rAF-throttled scroll listener → CSS variables
│   ├── useTheme.js           light / dark toggle (saved in localStorage)
│   ├── useTilt.js            3D card tilt
│   └── useRotatingText.js    rotating role text
├── utils/                    helpers: cn, skillLevel, format, evAnalytics (dashboard maths)
└── components/
    ├── layout/               Navbar, Footer, ScrollProgress, ThemeToggle
    ├── sections/             Hero, Marquee, About, Skills, Projects (+ FeaturedProjectCard), Contact
    ├── dashboard/            EV dashboard: EvDashboard, OverviewTab, DeepDiveTab, FilterRail, KpiCard, Gauge, Heatmap…
    └── ui/                   Button, Icon, Reveal, Section, SectionHeading, Web, WebDecor,
                              Spider (mascot), ScrollSpider, WebBurst, WebDivider, Intro, Modal, Sparkline
```

Each component has its own `*.module.css` (CSS Modules), so styles never leak between components.
Imports use the `@/` alias for `src/` (e.g. `import { profile } from '@/data'`).

## EV dashboard (Power BI → live)

`components/dashboard/` recreates the two pages of `EV_Adoption.pbix` (Overview + Deep dive) with the
same measures (Total Revenue, Units Sold, Revenue per Unit, Average Discount %) and Region / Brand slicers.
It opens in a full-screen dialog from the featured project card and is **lazy-loaded**, so the chart
library (Recharts) is only downloaded when a visitor opens it.

All numbers are computed in the browser from `src/data/ev/evSales.json` by the pure functions in
`src/utils/evAnalytics.js`. To refresh the data after you change the Power BI report (or from a CSV):

```bash
pip install pandas pbixray
python3 scripts/export-ev-data.py path/to/EV_Adoption.pbix   # or path/to/train.csv
```

Currency symbol: change `CURRENCY` in `src/utils/format.js`.

## Animations at a glance

| Effect                         | Where                              |
| ------------------------------ | ---------------------------------- |
| Hero portrait parallax         | `hooks/usePointerParallax.js`      |
| Hero web pulled by the cursor  | `components/ui/InteractiveWeb.jsx` |
| Mascot eyes follow the pointer | `hooks/useEyeTracking.js`          |
| Mascot lowering on a thread    | `components/ui/ScrollSpider.jsx`   |
| Click → web burst              | `components/ui/WebBurst.jsx`       |
| Self-drawing web strands       | `components/ui/WebDivider.jsx`     |
| Skills web (hover = red node)  | `components/sections/Skills.jsx`   |
| Letter-by-letter headings      | `components/ui/SectionHeading.jsx` |
| Intro (once per session)       | `components/ui/Intro.jsx`          |
| Spider walking on the strands  | `components/ui/WebDivider.jsx`     |
| Click the mascot → it climbs   | `components/ui/ScrollSpider.jsx`   |
| KPI numbers counting up        | `hooks/useCountUp.js`              |

All of them switch off automatically for visitors who enable "reduce motion". The mascot is hidden on small phones.

## Accessibility & performance

- Semantic landmarks, skip link, visible focus rings, `aria-current` on the active nav link
- Respects `prefers-reduced-motion` (animations are switched off)
- Theme is applied before first paint (no flash), no runtime dependencies besides React
- Production bundle ≈ 60 kB gzipped JS for the page; the dashboard adds ≈ 154 kB only when opened

## Deploy

Push to GitHub and import the repo on **Vercel** or **Netlify**
(build command `npm run build`, output directory `dist`). `vercel.json` is already included.
