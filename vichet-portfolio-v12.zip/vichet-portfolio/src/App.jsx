import { useScrollEffects } from '@/hooks'
import { Footer, Navbar, ScrollProgress } from '@/components/layout'
import { About, Contact, Hero, Marquee, Projects, Skills } from '@/components/sections'
import Intro from '@/components/ui/Intro'
import ScrollSpider from '@/components/ui/ScrollSpider'
import WebBurst from '@/components/ui/WebBurst'
import WebDivider from '@/components/ui/WebDivider'

export default function App() {
  useScrollEffects()

  return (
    <>
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <Intro />
      <ScrollProgress />
      <ScrollSpider />
      <WebBurst />
      <Navbar />
      <main id="main">
        <Hero />
        <Marquee />
        <About />
        <WebDivider />
        <Skills />
        <WebDivider flip />
        <Projects />
        <Contact />
      </main>
      <Footer />
    </>
  )
}
