import { useEffect } from 'react'

/**
 * Makes an element's "pupils" look at the pointer.
 * Publishes --ex / --ey (a small offset in SVG units) on the element; CSS moves the pupils with them.
 * @param {React.RefObject<Element>} ref  the element that owns the eyes
 * @param {number} reach  how far a pupil may travel from the centre of its eye
 */
export function useEyeTracking(ref, reach = 1.7) {
  useEffect(() => {
    const el = ref.current
    if (!el || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return undefined

    let frame = 0
    let px = 0
    let py = 0

    const update = () => {
      frame = 0
      const box = el.getBoundingClientRect()
      const dx = px - (box.left + box.width / 2)
      const dy = py - (box.top + box.height * 0.4) // the eyes sit in the upper part of the body
      const distance = Math.hypot(dx, dy) || 1
      const strength = Math.min(1, distance / 260) // look straight at the pointer only when it is close
      el.style.setProperty('--ex', ((dx / distance) * reach * strength).toFixed(2))
      el.style.setProperty('--ey', ((dy / distance) * reach * strength).toFixed(2))
    }
    const onMove = (e) => {
      px = e.clientX
      py = e.clientY
      if (!frame) frame = requestAnimationFrame(update)
    }

    window.addEventListener('pointermove', onMove, { passive: true })
    return () => {
      window.removeEventListener('pointermove', onMove)
      if (frame) cancelAnimationFrame(frame)
    }
  }, [ref, reach])
}
