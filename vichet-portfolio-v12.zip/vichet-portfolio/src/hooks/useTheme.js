import { useCallback, useState } from 'react'

const read = () => (document.documentElement.dataset.theme === 'dark' ? 'dark' : 'light')

/** Light / dark theme. The initial value is set by the inline script in index.html. */
export function useTheme() {
  const [theme, setTheme] = useState(read)

  const toggle = useCallback(() => {
    const next = read() === 'dark' ? 'light' : 'dark'
    document.documentElement.dataset.theme = next
    try {
      localStorage.setItem('theme', next)
    } catch {
      /* storage can be blocked (private mode) - the theme still changes for this visit */
    }
    setTheme(next)
  }, [])

  return { theme, toggle }
}
