import { useEffect, useState } from 'react'

/** Returns the id of the section currently crossing the middle of the screen. */
export function useScrollSpy(ids) {
  const [active, setActive] = useState('')
  const key = ids.join('|')

  useEffect(() => {
    const elements = key
      .split('|')
      .map((id) => document.getElementById(id))
      .filter(Boolean)
    if (!elements.length) return undefined

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => entry.isIntersecting && setActive(entry.target.id))
      },
      { rootMargin: '-45% 0px -50% 0px' },
    )
    elements.forEach((el) => io.observe(el))

    // Clear the highlight when the visitor scrolls back up to the hero.
    const onScroll = () => window.scrollY < 200 && setActive('')
    window.addEventListener('scroll', onScroll, { passive: true })

    return () => {
      io.disconnect()
      window.removeEventListener('scroll', onScroll)
    }
  }, [key])

  return active
}
