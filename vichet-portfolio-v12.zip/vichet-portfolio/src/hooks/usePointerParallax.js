import { useEffect, useRef } from 'react'

const clamp = (n) => Math.max(-1, Math.min(1, n))
const RATE = 5.5 // how quickly the layers follow the pointer (per second; higher = snappier)
const SETTLED = 0.002

/**
 * Publishes --px / --py (each between -1 and 1) on the element, based on where the pointer is in
 * the window, eased so layers glide instead of snapping. CSS uses them to shift layers by
 * different amounts (parallax). Sleeps when nothing is moving; off for reduced-motion visitors.
 * @returns {React.RefObject<HTMLElement>} attach to the element that owns the layers
 */
export function usePointerParallax() {
  const ref = useRef(null)

  useEffect(() => {
    const el = ref.current
    if (!el || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return undefined

    let targetX = 0
    let targetY = 0
    let x = 0
    let y = 0
    let frame = 0
    let prev = 0

    const render = (now) => {
      frame = 0
      // time-based easing: the glide feels identical on 60 Hz and 144 Hz screens
      const dt = Math.min((now - (prev || now)) / 1000, 1 / 20)
      prev = now
      const k = 1 - Math.exp(-dt * RATE)
      x += (targetX - x) * k
      y += (targetY - y) * k
      el.style.setProperty('--px', x.toFixed(3))
      el.style.setProperty('--py', y.toFixed(3))
      if (Math.abs(targetX - x) > SETTLED || Math.abs(targetY - y) > SETTLED) {
        frame = requestAnimationFrame(render)
      } else {
        prev = 0 // asleep: the next wake-up starts a fresh clock
      }
    }
    const wake = () => {
      if (!frame) frame = requestAnimationFrame(render)
    }
    const onMove = (e) => {
      targetX = clamp((e.clientX / window.innerWidth - 0.5) * 2)
      targetY = clamp((e.clientY / window.innerHeight - 0.5) * 2)
      wake()
    }
    const onLeave = () => {
      targetX = 0
      targetY = 0
      wake()
    }

    window.addEventListener('pointermove', onMove, { passive: true })
    document.documentElement.addEventListener('pointerleave', onLeave)
    return () => {
      window.removeEventListener('pointermove', onMove)
      document.documentElement.removeEventListener('pointerleave', onLeave)
      if (frame) cancelAnimationFrame(frame)
    }
  }, [])

  return ref
}
