import { useEffect, useState } from 'react'
import { usePrefersReducedMotion } from './usePrefersReducedMotion'

/** Cycles through `items` every `interval` ms. Stays on the first item for reduced-motion users. */
export function useRotatingText(items, interval = 2600) {
  const [index, setIndex] = useState(0)
  const reduced = usePrefersReducedMotion()

  useEffect(() => {
    if (reduced || items.length < 2) return undefined
    const id = setInterval(() => setIndex((i) => (i + 1) % items.length), interval)
    return () => clearInterval(id)
  }, [items.length, interval, reduced])

  return { text: items[index], index }
}
