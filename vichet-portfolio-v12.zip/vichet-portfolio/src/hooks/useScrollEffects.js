import { useEffect } from 'react'

/**
 * One throttled scroll listener that publishes values for CSS to use:
 *   --scroll-y     pixels scrolled (parallax decorations)
 *   --progress     0 → 1 through the page (progress bar)
 *   data-scrolled  "true" once the visitor leaves the very top (navbar style)
 */
export function useScrollEffects() {
  useEffect(() => {
    const root = document.documentElement
    let frame = 0

    const update = () => {
      frame = 0
      const y = window.scrollY
      const max = root.scrollHeight - window.innerHeight
      root.style.setProperty('--scroll-y', String(Math.round(y)))
      root.style.setProperty('--progress', max > 0 ? (y / max).toFixed(4) : '0')
      root.dataset.scrolled = y > 24 ? 'true' : 'false'
    }
    const onScroll = () => {
      if (!frame) frame = requestAnimationFrame(update)
    }

    update()
    window.addEventListener('scroll', onScroll, { passive: true })
    window.addEventListener('resize', onScroll)
    return () => {
      window.removeEventListener('scroll', onScroll)
      window.removeEventListener('resize', onScroll)
      if (frame) cancelAnimationFrame(frame)
    }
  }, [])
}
