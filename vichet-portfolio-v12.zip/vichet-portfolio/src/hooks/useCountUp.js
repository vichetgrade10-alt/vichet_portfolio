import { useEffect, useRef, useState } from 'react'

const easeOutCubic = (t) => 1 - (1 - t) ** 3

/**
 * Animates a number from its previous value to `target` (used for KPI cards when filters change).
 * Reduced-motion visitors get the final value immediately.
 */
export function useCountUp(target, duration = 900) {
  const [value, setValue] = useState(target)
  const from = useRef(target)

  useEffect(() => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (reduced || from.current === target) {
      from.current = target
      setValue(target)
      return undefined
    }

    const start = performance.now()
    const origin = from.current
    let frame = 0
    const tick = (now) => {
      const t = Math.min((now - start) / duration, 1)
      const current = origin + (target - origin) * easeOutCubic(t)
      from.current = current
      setValue(current)
      if (t < 1) frame = requestAnimationFrame(tick)
    }
    frame = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(frame)
  }, [target, duration])

  return value
}
