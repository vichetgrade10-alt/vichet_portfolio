/**
 * Pure functions that turn the raw EV sales rows into chart-ready data.
 * They mirror the DAX measures in the original Power BI report:
 *   Total Revenue    = SUM(Revenue)
 *   Total Units Sold = SUM(Units_Sold)
 *   Revenue per Unit = DIVIDE(SUM(Revenue), SUM(Units_Sold))
 *   Average Discount % = AVERAGE(Discount_Percentage)
 */

export const MONTH_LABELS = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
]

const monthIndex = (row) => Number(row.Date.slice(5, 7)) - 1

const sum = (rows, key) => rows.reduce((total, row) => total + row[key], 0)

/** Sum `valueKey` per distinct `groupKey`, returned as [{ name, value }] sorted high → low. */
function groupSum(rows, groupKey, valueKey) {
  const totals = new Map()
  rows.forEach((row) => totals.set(row[groupKey], (totals.get(row[groupKey]) ?? 0) + row[valueKey]))
  return [...totals].map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value)
}

/** Distinct sorted values of a column (used to build the slicers). */
export const distinct = (rows, key) => [...new Set(rows.map((r) => r[key]))].sort()

/** Empty selection = everything, exactly like an untouched Power BI slicer. */
export function filterRows(rows, { regions = [], brands = [] } = {}) {
  return rows.filter(
    (row) =>
      (regions.length === 0 || regions.includes(row.Region)) &&
      (brands.length === 0 || brands.includes(row.Brand)),
  )
}

export function computeKpis(rows) {
  const revenue = sum(rows, 'Revenue')
  const units = sum(rows, 'Units_Sold')
  const topModel = groupSum(rows, 'Model', 'Units_Sold')[0]
  return {
    records: rows.length,
    revenue,
    units,
    avgDiscount: rows.length ? sum(rows, 'Discount_Percentage') / rows.length : 0,
    revenuePerUnit: units ? revenue / units : 0,
    topModel: topModel?.name ?? '-',
    topModelUnits: topModel?.value ?? 0,
  }
}

/** Always 12 months so the axis does not jump around when filters remove a month. */
export function monthlyTotals(rows) {
  const months = MONTH_LABELS.map((month) => ({ month, revenue: 0, units: 0 }))
  rows.forEach((row) => {
    const m = months[monthIndex(row)]
    m.revenue += row.Revenue
    m.units += row.Units_Sold
  })
  return months
}

export function vehicleTypeStats(rows) {
  const stats = new Map()
  rows.forEach((row) => {
    const s = stats.get(row.Vehicle_Type) ?? { type: row.Vehicle_Type, revenue: 0, units: 0 }
    s.revenue += row.Revenue
    s.units += row.Units_Sold
    stats.set(row.Vehicle_Type, s)
  })
  return [...stats.values()].sort((a, b) => b.units - a.units)
}

export function brandShare(rows) {
  const brands = groupSum(rows, 'Brand', 'Units_Sold')
  const total = brands.reduce((t, b) => t + b.value, 0)
  return brands.map((b) => ({ ...b, share: total ? (b.value / total) * 100 : 0 }))
}

export function modelRanking(rows, count = 5) {
  const models = groupSum(rows, 'Model', 'Units_Sold')
  return {
    top: models.slice(0, count),
    worst: models.slice(-count).reverse(), // lowest first
  }
}

export const segmentRevenue = (rows) => groupSum(rows, 'Customer_Segment', 'Revenue')

export function monthlyUnitsByRegion(rows) {
  const regions = distinct(rows, 'Region')
  const data = MONTH_LABELS.map((month) => ({
    month,
    ...Object.fromEntries(regions.map((r) => [r, 0])),
  }))
  rows.forEach((row) => {
    data[monthIndex(row)][row.Region] += row.Units_Sold
  })
  return { data, regions }
}

/** One series per vehicle type: each sale record is a point (battery kWh vs revenue, sized by units). */
export function batteryScatter(rows) {
  const series = new Map()
  rows.forEach((row) => {
    const list = series.get(row.Vehicle_Type) ?? []
    list.push({
      type: row.Vehicle_Type,
      battery: row.Battery_Capacity_kWh,
      revenue: row.Revenue,
      units: row.Units_Sold,
    })
    series.set(row.Vehicle_Type, list)
  })
  return [...series]
    .map(([name, points]) => ({ name, points }))
    .sort((a, b) => a.name.localeCompare(b.name))
}

/** Average battery size per vehicle type, split by whether fast charging is offered. */
export function batteryByCharging(rows) {
  const acc = new Map()
  rows.forEach((row) => {
    const entry = acc.get(row.Vehicle_Type) ?? { type: row.Vehicle_Type, Yes: [], No: [] }
    entry[row.Fast_Charging_Option].push(row.Battery_Capacity_kWh)
    acc.set(row.Vehicle_Type, entry)
  })
  const avg = (list) => (list.length ? list.reduce((a, b) => a + b, 0) / list.length : 0)
  return [...acc.values()]
    .map((e) => ({ type: e.type, 'Fast charging': avg(e.Yes), 'No fast charging': avg(e.No) }))
    .sort((a, b) => a.type.localeCompare(b.type))
}

export function revenuePerUnitByModel(rows) {
  const stats = new Map()
  rows.forEach((row) => {
    const s = stats.get(row.Model) ?? { name: row.Model, revenue: 0, units: 0 }
    s.revenue += row.Revenue
    s.units += row.Units_Sold
    stats.set(row.Model, s)
  })
  return [...stats.values()]
    .map((s) => ({ name: s.name, value: s.revenue / s.units }))
    .sort((a, b) => b.value - a.value)
}

/** Brand × Region revenue grid for the heat-map table. */
export function brandRegionMatrix(rows) {
  const regions = distinct(rows, 'Region')
  const brands = distinct(rows, 'Brand')
  const cells = new Map()
  rows.forEach((row) => {
    const key = `${row.Brand}|${row.Region}`
    cells.set(key, (cells.get(key) ?? 0) + row.Revenue)
  })
  const matrix = brands.map((brand) => ({
    brand,
    values: regions.map((region) => cells.get(`${brand}|${region}`) ?? 0),
  }))
  const max = Math.max(0, ...matrix.flatMap((r) => r.values))
  return { regions, matrix, max }
}

/** A few plain-English takeaways, computed from whatever is currently filtered. */
export function buildInsights(rows) {
  if (!rows.length) return []
  const brands = brandShare(rows)
  const months = monthlyTotals(rows)
  const best = months.reduce((a, b) => (b.revenue > a.revenue ? b : a))
  const worst = months.reduce((a, b) => (b.revenue < a.revenue ? b : a))
  const regions = groupSum(rows, 'Region', 'Revenue')
  const segments = segmentRevenue(rows)
  const totalRevenue = sum(rows, 'Revenue')
  return [
    {
      label: 'Market leader',
      text: `${brands[0].name} sells the most units (${brands[0].share.toFixed(1)}% share).`,
    },
    {
      label: 'Peak month',
      text: `${best.month} is the strongest month for revenue; ${worst.month} is the weakest.`,
    },
    {
      label: 'Top region',
      text: `${regions[0].name} brings in ${((regions[0].value / totalRevenue) * 100).toFixed(0)}% of revenue.`,
    },
    { label: 'Best segment', text: `${segments[0].name} customers generate the most revenue.` },
  ]
}
