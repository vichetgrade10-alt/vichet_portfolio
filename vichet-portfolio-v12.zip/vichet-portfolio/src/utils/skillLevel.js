const LEVELS = [
  { min: 85, label: 'Expert' },
  { min: 70, label: 'Advanced' },
  { min: 50, label: 'Proficient' },
  { min: 0, label: 'Learning' },
]

/** Maps a 0-100 score to a human label. */
export const skillLabel = (level) => LEVELS.find((l) => level >= l.min).label
