/** Change this one constant if the revenue is not in US dollars. */
export const CURRENCY = '$'

const compact = new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 2 })
const whole = new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 })

/** 2611862520 → "2.61B" */
export const formatCompact = (n) => compact.format(n)

/** 2611862520 → "$2.61B" */
export const formatMoney = (n) => `${CURRENCY}${compact.format(n)}`

/** 21584.75 → "$21,585" */
export const formatMoneyExact = (n) => `${CURRENCY}${whole.format(n)}`

/** 121005 → "121,005" */
export const formatInt = (n) => whole.format(n)

/** 9.014 → "9.0%" */
export const formatPercent = (n, digits = 1) => `${n.toFixed(digits)}%`
