import evSummary from './ev/evSummary.json'

/**
 * ✏️ Add a project by copying one object.
 * - `links`     buttons under the card: { label, href } opens a new tab; no href opens the dashboard.
 * - `images`    optional screenshots (2+ show the left/right arrows).
 * - `dashboard` opens the interactive dashboard modal (see components/sections/Projects.jsx).
 */
export const projects = [
  {
    id: 'ev-adoption',
    title: 'EV Sales & Adoption Dashboard',
    description: `Interactive dashboard analysing ${evSummary.records} electric-vehicle sales records from 2023 across ${evSummary.regions} regions and ${evSummary.brands} brands: revenue trends, brand and model performance, customer segments and battery analysis. Originally built in Power BI, recreated here so you can filter and explore it live.`,
    tags: ['Power BI', 'DAX', 'Data Visualization', 'Business Analytics'],
    dashboard: 'ev-adoption',
    links: [{ label: 'Open dashboard' }],
    summary: evSummary,
  },
  {
    id: 'kravan',
    title: 'Data Visualize on Kravan Perfume Shop',
    description:
      'A data visualization project that turns Kravan Perfume Shop’s business data into clear charts and insights.',
    tags: ['Data Visualization', 'Business Analytics'],
    // images: [], // add screenshot paths to get the arrows carousel
    links: [],
  },
]
