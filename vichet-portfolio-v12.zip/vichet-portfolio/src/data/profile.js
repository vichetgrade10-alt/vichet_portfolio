/**
 * ✏️ EDIT YOUR PERSONAL DETAILS HERE
 * Everything shown on the site comes from the files in this folder.
 */
export const profile = {
  name: 'Vichet Out',
  initials: 'VO.',
  tagline: 'Your friendly neighborhood analyst',
  intro:
    'Digital Business student at CADT, passionate about business analytics, FinTech and the digital economy.',

  // Words that rotate under the hero name
  roles: [
    'Data Analysis',
    'Business Analytics',
    'Data Visualization',
    'FinTech',
    'Digital Economy',
  ],

  // Scrolling ribbons
  ribbon: [
    'Digital Business Student @CADT',
    'Data Analysis',
    'Business Analytics',
    'FinTech',
    'Digital Economy',
    'Data Visualization',
  ],

  about: [
    'I’m a Digital Business student at CADT with a passion for Business Analytics, FinTech and the Digital Economy.',
    'I enjoy turning data into clear visuals that help businesses make smarter decisions.',
  ],

  // Small fact cards in the About section
  highlights: [
    { label: 'Studying', value: 'Digital Business @ CADT' },
    { label: 'Focus', value: 'Data Analysis · FinTech · Digital Economy' },
    { label: 'Strength', value: 'Turning data into clear visuals' },
  ],

  // What you're open to - shown as badges in the hero and contact sections
  openTo: ['Internship', 'Collaboration', 'Volunteer', 'Work'],

  email: 'vichetgrade10@gmail.com',
  socials: {
    linkedin: 'https://www.linkedin.com/in/vichetout/',
    github: 'https://github.com/vichetgrade10-alt',
    facebook: 'https://www.facebook.com/orion4r/',
  },
}
