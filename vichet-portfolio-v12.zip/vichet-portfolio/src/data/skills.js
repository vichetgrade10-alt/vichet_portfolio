/**
 * `featured: true` skills have no level and are shown as the toolkit card above the web.
 * level: 1-100. It drives the bar width and the label (see utils/skillLevel.js).
 * ✏️ Adjust these numbers so they honestly reflect where you are today.
 */
export const skills = [
  { name: 'Data Analysis', featured: true, note: 'Messy datasets into clear narratives' },
  { name: 'Business Analytics', level: 80, note: 'Turning business questions into insights' },
  { name: 'Data Visualization', level: 85, note: 'Clear charts and dashboards' },
  { name: 'FinTech', level: 65, note: 'Digital payments and financial innovation' },
  { name: 'Digital Economy', level: 70, note: 'How technology reshapes markets' },
  { name: 'Digital Business', level: 75, note: 'Strategy for a digital-first world' },
]

/** Tools behind the Data Analysis skill (shown as chips). `hue` tints the little badge. */
export const dataTools = [
  { name: 'Python', mark: 'Py', hue: '#3776ab' },
  { name: 'Pandas', mark: 'Pd', hue: '#5b3b8f' },
  { name: 'SQL', mark: 'DB', hue: '#2b8a9b' },
  { name: 'Matplotlib', mark: 'Mp', hue: '#d9792b' },
  { name: 'Seaborn', mark: 'Sb', hue: '#4c78a8' },
  { name: 'Jupyter', mark: 'Jp', hue: '#f37726' },
  { name: 'Power BI', mark: 'PB', hue: '#e0a800' },
  { name: 'Tableau', mark: 'Tb', hue: '#c8102e' },
]
