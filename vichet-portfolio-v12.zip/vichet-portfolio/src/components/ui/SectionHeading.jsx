import { useInView } from '@/hooks'
import { cn } from '@/utils/cn'
import styles from './SectionHeading.module.css'

/** Splits a title into words (kept whole) of letters, numbering each letter for a stagger delay. */
const splitTitle = (title) =>
  title.split(' ').reduce((words, text) => {
    const start = words.length ? words[words.length - 1].end : 0
    words.push({ text, start, end: start + text.length })
    return words
  }, [])

export default function SectionHeading({ id, eyebrow, title, align = 'left' }) {
  const [ref, inView] = useInView({ threshold: 0.4 })

  return (
    <div
      ref={ref}
      className={cn(styles.heading, align === 'center' && styles.center, inView && styles.in)}
    >
      <span className={styles.eyebrow}>{eyebrow}</span>
      <h2 id={id} className={styles.title} aria-label={title}>
        {splitTitle(title).map(({ text, start }) => (
          <span key={start} className={styles.word} aria-hidden="true">
            {[...text].map((char, i) => (
              <span key={i} className={styles.char} style={{ '--i': start + i }}>
                {char}
              </span>
            ))}
            {' '}
          </span>
        ))}
      </h2>
      <span className={styles.bar} aria-hidden="true" />
    </div>
  )
}
