import { useEffect, useRef, useState } from 'react'
import { cn } from '@/utils/cn'
import Spider from './Spider'
import styles from './ScrollSpider.module.css'

const CLIMB_MS = 1500

/**
 * The mascot hangs from the top of the screen on a thread that lowers as you scroll
 * (driven by the --progress CSS variable from useScrollEffects) and sways gently.
 * Click it and it zips up out of sight, then drops back down with a bounce.
 */
export default function ScrollSpider() {
  const [climbing, setClimbing] = useState(false)
  const timer = useRef(0)

  useEffect(() => () => clearTimeout(timer.current), [])

  const climb = () => {
    if (climbing) return
    setClimbing(true)
    timer.current = setTimeout(() => setClimbing(false), CLIMB_MS)
  }

  return (
    <div className={styles.wrap}>
      <div className={cn(styles.sway, climbing && styles.climb)}>
        <span className={styles.thread} aria-hidden="true" />
        <button
          type="button"
          className={styles.hit}
          onClick={climb}
          aria-label="Make the spider climb up and drop back down"
        >
          <Spider size={58} className={styles.spider} />
        </button>
        <span className={styles.bubble} aria-hidden="true">
          Hi! Click me 🕷️
        </span>
      </div>
    </div>
  )
}
