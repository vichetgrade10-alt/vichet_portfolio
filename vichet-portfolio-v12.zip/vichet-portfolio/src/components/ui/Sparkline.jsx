import { useId } from 'react'
import { useInView } from '@/hooks'
import { cn } from '@/utils/cn'
import styles from './Sparkline.module.css'

const W = 300
const H = 90
const PAD = 8

/** Tiny area chart that draws itself when scrolled into view. Decorative: numbers live next to it. */
export default function Sparkline({ values }) {
  const [ref, inView] = useInView({ threshold: 0.4 })
  const gradientId = useId()

  const max = Math.max(...values)
  const min = Math.min(...values)
  const points = values.map((v, i) => [
    PAD + (i / (values.length - 1)) * (W - PAD * 2),
    PAD + (1 - (v - min) / (max - min || 1)) * (H - PAD * 2),
  ])
  const line = points
    .map(([x, y], i) => `${i ? 'L' : 'M'}${x.toFixed(1)} ${y.toFixed(1)}`)
    .join(' ')
  const area = `${line} L${points.at(-1)[0]} ${H} L${points[0][0]} ${H} Z`
  const [lastX, lastY] = points.at(-1)

  return (
    <svg
      ref={ref}
      className={cn(styles.spark, inView && styles.in)}
      viewBox={`0 0 ${W} ${H}`}
      preserveAspectRatio="none"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="var(--red)" stopOpacity="0.35" />
          <stop offset="100%" stopColor="var(--red)" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path className={styles.area} d={area} fill={`url(#${gradientId})`} />
      <path className={styles.line} d={line} pathLength="1" />
      <circle className={styles.dot} cx={lastX} cy={lastY} r="4" />
    </svg>
  )
}
