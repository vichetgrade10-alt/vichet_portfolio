import { useRef } from 'react'
import { useEyeTracking } from '@/hooks'
import { cn } from '@/utils/cn'
import styles from './Spider.module.css'

/** Original friendly spider mascot. Legs wiggle on their own and the eyes follow the pointer. */
export default function Spider({ size = 56, className }) {
  const ref = useRef(null)
  useEyeTracking(ref)

  return (
    <svg
      ref={ref}
      className={cn(styles.spider, className)}
      width={size}
      height={size}
      viewBox="0 0 80 80"
      aria-hidden="true"
    >
      <g className={cn(styles.legs, styles.l)}>
        <path d="M31 38 Q13 26 6 36" />
        <path d="M30 44 Q10 42 4 54" />
        <path d="M30 50 Q12 58 9 72" />
        <path d="M33 56 Q24 66 24 77" />
      </g>
      <g className={cn(styles.legs, styles.r)}>
        <path d="M49 38 Q67 26 74 36" />
        <path d="M50 44 Q70 42 76 54" />
        <path d="M50 50 Q68 58 71 72" />
        <path d="M47 56 Q56 66 56 77" />
      </g>

      <ellipse className={styles.body} cx="40" cy="54" rx="15" ry="17" />
      <path className={styles.mark} d="M35 48H45L40 54L45 60H35L40 54Z" />
      <circle className={styles.body} cx="40" cy="32" r="12" />
      <circle className={styles.eye} cx="35" cy="31" r="4" />
      <circle className={styles.eye} cx="45" cy="31" r="4" />
      <circle className={styles.pupil} cx="36" cy="32" r="1.8" />
      <circle className={styles.pupil} cx="46" cy="32" r="1.8" />
    </svg>
  )
}
