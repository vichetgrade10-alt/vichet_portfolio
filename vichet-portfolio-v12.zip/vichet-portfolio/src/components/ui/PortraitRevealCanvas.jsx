import { useEffect, useRef, useState } from 'react'
import styles from './PortraitReveal.module.css'

/**
 * Liquid cursor-reveal.
 *
 * Fallback used when WebGL is unavailable (see PortraitReveal.jsx).
 * `base` (you) sits on top of `reveal` (Spider-Man). A canvas draws `base` and then erases it
 * wherever a soft "liquid" mask is. The mask is a field of radial blobs (one per trail point):
 *   - a threshold on the field gives soft metaball edges that merge as blobs touch,
 *   - the band right at the threshold is painted gold (the glowing outline),
 *   - every blob loses strength with age, so the trail shrinks away and heals in ~1.5s.
 * Touch drag paints too, and on touch devices an idle sweep plays every few seconds.
 */

const LIFE = 1.5 // seconds until a blob has fully healed
const THRESHOLD = 0.5 // field value where the liquid edge sits
const MASK_W = 280 // mask resolution (height follows the 2:3 portrait ratio)
const MASK_H = 420
const BLOB_R = 54 // blob radius in mask pixels
const SPACING = 5 // distance between blobs along a stroke (mask pixels)
const GOLD = [255, 201, 60]

const smooth = (a, b, x) => {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)))
  return t * t * (3 - 2 * t)
}

/** A looping S-curve across the portrait (0..1 coordinates) used for the idle sweep. */
const sweepPath = (u) => ({
  x: 0.12 + 0.76 * u,
  y: 0.3 + 0.32 * u + 0.16 * Math.sin(u * Math.PI * 2.4),
})

export default function PortraitRevealCanvas({ base, reveal, baseAlt, width = 800, height = 1200 }) {
  const wrapRef = useRef(null)
  const canvasRef = useRef(null)
  const [ready, setReady] = useState(false)
  const [touched, setTouched] = useState(false)

  useEffect(() => {
    const wrap = wrapRef.current
    const canvas = canvasRef.current
    if (!wrap || !canvas) return undefined

    const ctx = canvas.getContext('2d')
    const mask = document.createElement('canvas')
    mask.width = MASK_W
    mask.height = MASK_H
    const mctx = mask.getContext('2d', { willReadFrequently: true })
    const reveal$ = document.createElement('canvas')
    const glow$ = document.createElement('canvas')
    reveal$.width = glow$.width = MASK_W
    reveal$.height = glow$.height = MASK_H
    const rctx = reveal$.getContext('2d')
    const gctx = glow$.getContext('2d')
    const rImg = rctx.createImageData(MASK_W, MASK_H)
    const gImg = gctx.createImageData(MASK_W, MASK_H)

    const baseImg = new Image()
    const revealImg = new Image()
    const rev$ = document.createElement('canvas') // the spider, cut to the lens shape
    const rrctx = rev$.getContext('2d')
    let loaded = 0

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const coarse = window.matchMedia('(hover: none), (pointer: coarse)').matches

    let points = [] // { x, y, born, seed }  (mask coordinates)
    let raf = 0
    let alive = true
    let last = null // last emitted point
    let pos = null // smoothed pointer
    let target = null
    let lastInput = performance.now()
    let sweeping = 0
    let visible = true

    const fit = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2)
      const w = wrap.clientWidth
      const h = wrap.clientHeight
      canvas.width = rev$.width = Math.round(w * dpr)
      canvas.height = rev$.height = Math.round(h * dpr)
      draw(performance.now())
    }

    const emit = (x, y, now) => {
      if (last) {
        const dx = x - last.x
        const dy = y - last.y
        const dist = Math.hypot(dx, dy)
        const n = Math.floor(dist / SPACING)
        for (let i = 1; i <= n; i += 1) {
          const t = i / (n + 1)
          points.push({
            x: last.x + dx * t,
            y: last.y + dy * t,
            born: now,
            seed: Math.random() * 6.28,
          })
        }
        if (n > 0) last = points[points.length - 1]
      } else {
        points.push({ x, y, born: now, seed: Math.random() * 6.28 })
        last = points[points.length - 1]
      }
      if (points.length > 260) points = points.slice(-260)
      start()
    }

    /** Paint the blob field, threshold it, then composite the portrait. */
    function draw(now) {
      const t = now / 1000
      mctx.globalCompositeOperation = 'source-over'
      mctx.fillStyle = '#000'
      mctx.fillRect(0, 0, MASK_W, MASK_H)
      mctx.globalCompositeOperation = 'lighten'

      for (const p of points) {
        const age = (now - p.born) / 1000 / LIFE
        if (age >= 1) continue
        // the blob shrinks to a point as it ages (and loses a little strength), so it heals cleanly
        const strength = 1 - 0.3 * age
        const wobble = 1 + 0.09 * Math.sin(t * 5 + p.seed)
        const r = BLOB_R * wobble * (1 - 0.92 * age ** 0.9)
        const g = mctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, r)
        const v = (k) => `rgb(${Math.round(255 * strength * k)},0,0)`
        g.addColorStop(0, v(1))
        g.addColorStop(0.35, v(0.82))
        g.addColorStop(0.7, v(0.3))
        g.addColorStop(1, v(0))
        mctx.fillStyle = g
        mctx.fillRect(p.x - r, p.y - r, r * 2, r * 2)
      }

      const src = mctx.getImageData(0, 0, MASK_W, MASK_H).data
      const rd = rImg.data
      const gd = gImg.data
      for (let i = 0, n = MASK_W * MASK_H; i < n; i += 1) {
        const f = src[i * 4] / 255
        const d = f - THRESHOLD
        const inside = smooth(THRESHOLD - 0.045, THRESHOLD + 0.045, f)
        // sharp gold line at the edge + a wider, softer halo around it
        let glow =
          Math.exp(-(d * d) / (2 * 0.035 * 0.035)) * 0.95 +
          Math.exp(-(d * d) / (2 * 0.16 * 0.16)) * 0.24
        if (f < 0.08) glow = 0
        const o = i * 4
        rd[o] = rd[o + 1] = rd[o + 2] = 0
        rd[o + 3] = inside * 255
        gd[o] = GOLD[0]
        gd[o + 1] = GOLD[1]
        gd[o + 2] = GOLD[2]
        gd[o + 3] = Math.min(1, glow) * 255
      }
      rctx.putImageData(rImg, 0, 0)
      gctx.putImageData(gImg, 0, 0)

      const W = canvas.width
      const H = canvas.height
      ctx.globalCompositeOperation = 'source-over'
      ctx.clearRect(0, 0, W, H)
      ctx.imageSmoothingQuality = 'high'
      const ready$ = baseImg.complete && baseImg.naturalWidth && revealImg.complete
      if (ready$) {
        // the Spider-Man photo, kept only where the lens is
        rrctx.globalCompositeOperation = 'source-over'
        rrctx.clearRect(0, 0, W, H)
        rrctx.drawImage(revealImg, 0, 0, W, H)
        rrctx.globalCompositeOperation = 'destination-in'
        rrctx.drawImage(reveal$, 0, 0, W, H)
        // you, with the lens cut out, and Spider-Man showing through behind
        ctx.drawImage(baseImg, 0, 0, W, H)
        ctx.globalCompositeOperation = 'destination-out'
        ctx.drawImage(reveal$, 0, 0, W, H)
        ctx.globalCompositeOperation = 'destination-over'
        ctx.drawImage(rev$, 0, 0, W, H)
      }
      ctx.globalCompositeOperation = 'source-over'
      ctx.drawImage(glow$, 0, 0, W, H)
    }

    function frame(now) {
      raf = 0
      if (!alive) return
      // follow the pointer with a little lag so strokes are smooth and organic
      if (target) {
        if (!pos) pos = { ...target }
        pos.x += (target.x - pos.x) * 0.24
        pos.y += (target.y - pos.y) * 0.24
        emit(pos.x, pos.y, now)
      }
      points = points.filter((p) => now - p.born < LIFE * 1000)
      draw(now)
      if (points.length || target) start()
      else {
        last = null
        pos = null
      }
    }
    function start() {
      if (!raf && alive) raf = requestAnimationFrame(frame)
    }

    const toMask = (e) => {
      const b = wrap.getBoundingClientRect()
      return {
        x: ((e.clientX - b.left) / b.width) * MASK_W,
        y: ((e.clientY - b.top) / b.height) * MASK_H,
      }
    }
    const onMove = (e) => {
      target = toMask(e)
      lastInput = performance.now()
      setTouched(true)
      start()
    }
    const onLeave = () => {
      target = null
    }

    /** Scripted brush stroke (intro + idle sweep on touch screens). */
    const sweep = () => {
      if (sweeping || reduced) return
      const t0 = performance.now()
      const dur = 1700
      sweeping = 1
      const step = (now) => {
        const u = Math.min(1, (now - t0) / dur)
        const p = sweepPath(u * u * (3 - 2 * u))
        target = { x: p.x * MASK_W, y: p.y * MASK_H }
        if (u < 1 && alive) requestAnimationFrame(step)
        else {
          target = null
          sweeping = 0
        }
        start()
      }
      requestAnimationFrame(step)
    }

    wrap.addEventListener('pointermove', onMove)
    wrap.addEventListener('pointerdown', onMove)
    wrap.addEventListener('pointerleave', onLeave)
    wrap.addEventListener('pointerup', (e) => e.pointerType !== 'mouse' && onLeave())
    wrap.addEventListener('pointercancel', onLeave)

    const ro = new ResizeObserver(fit)
    ro.observe(wrap)
    const io = new IntersectionObserver(([en]) => {
      visible = en.isIntersecting
    })
    io.observe(wrap)

    const onLoaded = () => {
      loaded += 1
      if (loaded < 2) return
      fit()
      setReady(true)
      if (!reduced) setTimeout(sweep, 1400) // a first sweep so visitors see what the portrait does
    }
    baseImg.onload = onLoaded
    revealImg.onload = onLoaded
    baseImg.src = base
    revealImg.src = reveal

    const idle = coarse
      ? setInterval(() => {
          if (visible && !document.hidden && performance.now() - lastInput > 3500) sweep()
        }, 4200)
      : 0

    return () => {
      alive = false
      cancelAnimationFrame(raf)
      clearInterval(idle)
      ro.disconnect()
      io.disconnect()
      wrap.removeEventListener('pointermove', onMove)
      wrap.removeEventListener('pointerdown', onMove)
      wrap.removeEventListener('pointerleave', onLeave)
    }
  }, [base, reveal])

  return (
    <div ref={wrapRef} className={styles.wrap} style={{ aspectRatio: `${width} / ${height}` }}>
      {/* the canvas takes over once ready; this image is the no-JS / loading state */}
      <img
        className={styles.layer}
        src={base}
        width={width}
        height={height}
        alt={baseAlt}
        fetchPriority="high"
        style={{ opacity: ready ? 0 : 1 }}
      />
      <canvas ref={canvasRef} className={styles.canvas} aria-hidden="true" />
      <span className={styles.hint} data-gone={touched} aria-hidden="true">
        Move over me
      </span>
    </div>
  )
}
