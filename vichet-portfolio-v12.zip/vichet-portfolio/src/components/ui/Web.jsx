import { useMemo } from 'react'

const SPOKES = 12
const RINGS = [14, 35, 56, 77, 98]
const point = (radius, i) => [
  100 + radius * Math.cos((i * 2 * Math.PI) / SPOKES),
  100 + radius * Math.sin((i * 2 * Math.PI) / SPOKES),
]

/** Decorative spider-web. Size and position it from the parent with `className` / `style`. */
export default function Web({ className, style }) {
  const { spokes, rings } = useMemo(
    () => ({
      spokes: Array.from({ length: SPOKES }, (_, i) => point(98, i)),
      rings: RINGS.map((r) =>
        Array.from({ length: SPOKES + 1 }, (_, i) => {
          const [x, y] = point(r, i)
          return `${i ? 'L' : 'M'}${x.toFixed(1)} ${y.toFixed(1)}`
        }).join(''),
      ),
    }),
    [],
  )

  return (
    <svg
      className={className}
      style={style}
      viewBox="0 0 200 200"
      preserveAspectRatio="xMidYMid slice"
      fill="none"
      stroke="currentColor"
      strokeWidth=".8"
      aria-hidden="true"
    >
      {spokes.map(([x, y], i) => (
        <line key={i} x1="100" y1="100" x2={x} y2={y} pathLength="1" style={{ '--i': i }} />
      ))}
      {rings.map((d, i) => (
        <path key={d} d={d} pathLength="1" style={{ '--i': SPOKES + i * 2 }} />
      ))}
    </svg>
  )
}
