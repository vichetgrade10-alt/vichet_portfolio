import { useEffect, useId, useRef } from 'react'
import Icon from './Icon'
import styles from './Modal.module.css'

/**
 * Full-screen dialog built on the native <dialog> element, so focus-trapping,
 * Escape-to-close and the backdrop come from the browser. Children mount only while open.
 */
export default function Modal({ open, onClose, title, subtitle, children }) {
  const ref = useRef(null)
  const titleId = useId()

  // Open / close the native dialog and lock page scroll while it is visible.
  useEffect(() => {
    const dialog = ref.current
    if (!dialog) return undefined
    if (open && !dialog.open) dialog.showModal()
    if (!open && dialog.open) dialog.close()

    document.documentElement.classList.toggle('modal-open', open)
    return () => document.documentElement.classList.remove('modal-open')
  }, [open])

  return (
    <dialog
      ref={ref}
      className={styles.dialog}
      aria-labelledby={titleId}
      onClose={onClose}
      // A click on the dark backdrop targets the <dialog> itself.
      onClick={(e) => e.target === ref.current && onClose()}
    >
      <div className={styles.panel}>
        <header className={styles.header}>
          <div>
            <h2 id={titleId} className={styles.title}>
              {title}
            </h2>
            {subtitle && <p className={styles.subtitle}>{subtitle}</p>}
          </div>
          <button
            type="button"
            className={styles.close}
            onClick={onClose}
            aria-label="Close dashboard"
          >
            <Icon name="close" size={20} />
          </button>
        </header>
        <div className={styles.body}>{open && children}</div>
      </div>
    </dialog>
  )
}
