import { useEffect, useRef } from 'react'
import styles from './InteractiveWeb.module.css'

const SPOKES = 16
const RINGS = 9
const REACH = 260 // px - how close the pointer must be to tug a strand
const PULL = 0.55 // how far a strand is dragged toward the pointer (0-1)
const STIFFNESS = 0.1 // spring strength back to rest
const DAMPING = 0.8 // lower = settles faster
const SETTLED = 0.05 // total movement below which the animation loop stops

/** True for the few knots that carry a red "dewdrop" (fixed pattern, so it never flickers). */
const hasDew = (spoke, ring) => (spoke * 7 + ring * 3) % 11 === 0

/**
 * A spider-web drawn on a canvas. Every knot is on a spring: move the pointer near the web
 * and the strands stretch toward it, then wobble back. The loop sleeps when nothing moves.
 */
export default function InteractiveWeb() {
  const canvasRef = useRef(null)

  useEffect(() => {
    const canvas = canvasRef.current
    const ctx = canvas?.getContext('2d')
    if (!canvas || !ctx) return undefined

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const pointer = { x: 0, y: 0, active: false }
    let nodes = []
    let width = 0
    let height = 0
    let cx = 0
    let cy = 0
    let frame = 0

    const node = (spoke, ring) => nodes[(spoke % SPOKES) * RINGS + ring - 1]

    const build = () => {
      const box = canvas.getBoundingClientRect()
      width = box.width
      height = box.height
      const dpr = Math.min(window.devicePixelRatio || 1, 2)
      canvas.width = Math.round(width * dpr)
      canvas.height = Math.round(height * dpr)
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)

      // Centre the web behind the portrait (right side on desktop, lower middle on phones).
      const narrow = width < 860
      cx = narrow ? width * 0.5 : width / 2 + Math.min(width, 1200) * 0.24
      cy = narrow ? height * 0.72 : height * 0.5
      const radius = Math.min(width, height) * (narrow ? 0.55 : 0.68)

      nodes = []
      for (let s = 0; s < SPOKES; s += 1) {
        const angle = (s / SPOKES) * Math.PI * 2 - Math.PI / 2
        for (let r = 1; r <= RINGS; r += 1) {
          const dist = radius * Math.pow(r / RINGS, 1.12) // rings bunch up toward the centre
          const x = cx + Math.cos(angle) * dist
          const y = cy + Math.sin(angle) * dist
          nodes.push({ rx: x, ry: y, x, y, vx: 0, vy: 0 })
        }
      }
    }

    /** Moves every knot one spring step. Returns how much things are still moving. */
    const step = () => {
      let energy = 0
      for (const n of nodes) {
        let tx = n.rx
        let ty = n.ry
        if (pointer.active) {
          const dx = pointer.x - n.rx
          const dy = pointer.y - n.ry
          const d = Math.hypot(dx, dy)
          if (d < REACH) {
            const pull = (1 - d / REACH) ** 2 * PULL
            tx += dx * pull
            ty += dy * pull
          }
        }
        n.vx = (n.vx + (tx - n.x) * STIFFNESS) * DAMPING
        n.vy = (n.vy + (ty - n.y) * STIFFNESS) * DAMPING
        n.x += n.vx
        n.y += n.vy
        energy += Math.abs(n.vx) + Math.abs(n.vy) + Math.abs(tx - n.x) * 0.01
      }
      return energy
    }

    const draw = () => {
      const styleOf = getComputedStyle(canvas)
      const red = styleOf.getPropertyValue('--red').trim() || '#c8102e'
      ctx.clearRect(0, 0, width, height)

      ctx.strokeStyle = styleOf.color
      ctx.lineWidth = 1.1
      ctx.globalAlpha = 0.42

      // spokes
      ctx.beginPath()
      for (let s = 0; s < SPOKES; s += 1) {
        ctx.moveTo(cx, cy)
        for (let r = 1; r <= RINGS; r += 1) ctx.lineTo(node(s, r).x, node(s, r).y)
      }
      ctx.stroke()

      // rings - each segment sags a little toward the centre, like real silk
      ctx.beginPath()
      for (let r = 1; r <= RINGS; r += 1) {
        for (let s = 0; s < SPOKES; s += 1) {
          const a = node(s, r)
          const b = node(s + 1, r)
          const mx = (a.x + b.x) / 2
          const my = (a.y + b.y) / 2
          if (s === 0) ctx.moveTo(a.x, a.y)
          ctx.quadraticCurveTo(mx + (cx - mx) * 0.07, my + (cy - my) * 0.07, b.x, b.y)
        }
      }
      ctx.stroke()

      // dewdrops
      ctx.globalAlpha = 0.75
      ctx.fillStyle = red
      for (let s = 0; s < SPOKES; s += 1) {
        for (let r = 2; r <= RINGS; r += 1) {
          if (!hasDew(s, r)) continue
          const n = node(s, r)
          ctx.beginPath()
          ctx.arc(n.x, n.y, 2.4, 0, Math.PI * 2)
          ctx.fill()
        }
      }
      ctx.globalAlpha = 1
    }

    const loop = () => {
      frame = 0
      const energy = step()
      draw()
      // sleep as soon as nothing is moving (a stationary pointer needs no frames)
      if (energy > SETTLED) frame = requestAnimationFrame(loop)
    }
    const wake = () => {
      if (!frame) frame = requestAnimationFrame(loop)
    }

    const onMove = (e) => {
      const box = canvas.getBoundingClientRect()
      pointer.x = e.clientX - box.left
      pointer.y = e.clientY - box.top
      // only react while the pointer is on (or near) the web's area
      pointer.active =
        pointer.x > -REACH &&
        pointer.x < width + REACH &&
        pointer.y > -REACH &&
        pointer.y < height + REACH
      wake()
    }
    const onLeave = () => {
      pointer.active = false
      wake()
    }

    build()
    draw()

    const resize = new ResizeObserver(() => {
      build()
      draw()
    })
    resize.observe(canvas)

    // Re-colour when the visitor switches light / dark.
    const theme = new MutationObserver(draw)
    theme.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] })

    if (!reduced) {
      window.addEventListener('pointermove', onMove, { passive: true })
      document.documentElement.addEventListener('pointerleave', onLeave)
    }

    return () => {
      if (frame) cancelAnimationFrame(frame)
      resize.disconnect()
      theme.disconnect()
      window.removeEventListener('pointermove', onMove)
      document.documentElement.removeEventListener('pointerleave', onLeave)
    }
  }, [])

  return <canvas ref={canvasRef} className={styles.canvas} aria-hidden="true" />
}
