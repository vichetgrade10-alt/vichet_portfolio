import { useEffect, useRef, useState } from 'react'
import { usePrefersReducedMotion } from '@/hooks'
import Web from './Web'
import styles from './WebBurst.module.css'

const LIFETIME = 800 // ms - keep in sync with the animation in WebBurst.module.css
const MAX_AT_ONCE = 6

/** Every click or tap "shoots" a small web that expands and fades where you pressed. */
export default function WebBurst() {
  const [bursts, setBursts] = useState([])
  const counter = useRef(0)
  const reduced = usePrefersReducedMotion()

  useEffect(() => {
    if (reduced) return undefined

    const onClick = (e) => {
      const id = ++counter.current
      const burst = {
        id,
        x: e.clientX,
        y: e.clientY,
        rotation: Math.round(Math.random() * 40 - 20),
      }
      setBursts((list) => [...list.slice(-(MAX_AT_ONCE - 1)), burst])
      setTimeout(() => setBursts((list) => list.filter((b) => b.id !== id)), LIFETIME)
    }

    window.addEventListener('click', onClick)
    return () => window.removeEventListener('click', onClick)
  }, [reduced])

  return (
    <div className={styles.layer} aria-hidden="true">
      {bursts.map((b) => (
        <Web
          key={b.id}
          className={styles.burst}
          style={{ left: b.x, top: b.y, '--rotation': `${b.rotation}deg` }}
        />
      ))}
    </div>
  )
}
