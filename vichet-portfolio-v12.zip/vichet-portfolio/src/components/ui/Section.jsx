import { cn } from '@/utils/cn'
import styles from './Section.module.css'

/** Standard page section: consistent width, spacing and scroll anchor. */
export default function Section({ id, labelledBy, className, children }) {
  return (
    <section id={id} aria-labelledby={labelledBy} className={cn(styles.section, className)}>
      {children}
    </section>
  )
}
