import { useInView } from '@/hooks'
import { cn } from '@/utils/cn'
import styles from './Reveal.module.css'

/** Fades + slides its children up the first time they scroll into view. */
export default function Reveal({
  as: Tag = 'div',
  delay = 0,
  className,
  style,
  children,
  ...rest
}) {
  const [ref, inView] = useInView()
  return (
    <Tag
      ref={ref}
      className={cn(styles.reveal, inView && styles.in, className)}
      style={{ '--delay': `${delay}ms`, ...style }}
      {...rest}
    >
      {children}
    </Tag>
  )
}
