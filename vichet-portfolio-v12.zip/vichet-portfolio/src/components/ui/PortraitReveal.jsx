import { useEffect, useRef, useState } from 'react'
import PortraitRevealCanvas from './PortraitRevealCanvas'
import styles from './PortraitReveal.module.css'

/**
 * Liquid cursor-reveal, drawn on the GPU.
 *
 * `base` (you, transparent cut-out) sits on top of `reveal` (Spider-Man, also a cut-out). A fragment
 * shader decides, per pixel, how much of `base` is erased by a liquid lens that follows the pointer:
 *   - the lens head is driven by a spring (slight overshoot, so it glides and settles instead of
 *     snapping), and stretches a little with speed,
 *   - it leaves a trail of blobs that taper away and heal in about a second,
 *   - the edge is a signed-distance estimate, so the gold rim stays crisp and the same thickness
 *     at any size or pixel density, with no stair-stepping.
 * Touch drag paints too, and on touch screens an idle sweep plays every few seconds.
 * If WebGL is missing or fails, it falls back to the 2D-canvas version.
 */

const MAX_PTS = 24 // blobs sent to the shader (1 head + trail)
const R = 0.25 // blob support radius, in portrait widths
const LIFE = 0.95 // seconds for a trail blob to heal
const SPACING = 0.03 // distance between trail blobs (portrait widths)
const STIFFNESS = 300 // spring: how hard the lens is pulled to the pointer
const DAMPING = 26 // spring: friction (a little under critical, so it settles with a tiny float)
const GOLD = [1.0, 0.79, 0.24]

const VERT = `
attribute vec2 aPos;
varying vec2 vUv;
void main() {
  vUv = vec2(aPos.x * 0.5 + 0.5, 0.5 - aPos.y * 0.5);
  gl_Position = vec4(aPos, 0.0, 1.0);
}`

const FRAG = `
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 vUv;
uniform sampler2D uBase;
uniform sampler2D uReveal;
uniform vec4 uPts[${MAX_PTS}]; // x, y (portrait units), radius, strength
uniform float uAspect;         // height / width
uniform float uCssW;           // stage width in CSS pixels
uniform vec3 uGold;

void main() {
  vec2 p = vec2(vUv.x, vUv.y * uAspect);

  // field = the strongest blob here, plus its gradient (for an edge-distance estimate)
  float f = 0.0;
  vec2 g = vec2(0.0);
  for (int i = 0; i < ${MAX_PTS}; i++) {
    vec4 c = uPts[i];
    if (c.z > 0.0) {
      vec2 d = p - c.xy;
      float q2 = dot(d, d) / (c.z * c.z);
      if (q2 < 1.0) {
        float w = 1.0 - q2;
        float k = c.w * w * w * w;
        if (k > f) {
          f = k;
          g = -6.0 * c.w * w * w * d / (c.z * c.z);
        }
      }
    }
  }

  // signed distance to the lens edge in CSS pixels (positive = inside)
  float sd = (f - 0.5) / max(length(g), 0.0001) * uCssW;
  float inside = smoothstep(-0.8, 0.8, sd);

  // gold rim: a crisp line plus a soft glow on both sides
  float line = 1.0 - smoothstep(1.1, 2.7, abs(sd));
  float halo = (1.0 - inside) * exp(-max(-sd, 0.0) / 9.0) * 0.30
             + inside * exp(-max(sd, 0.0) / 5.0) * 0.10;
  float glow = clamp(line + halo, 0.0, 1.0) * step(0.02, f);
  vec3 rim = mix(uGold, vec3(1.0, 0.93, 0.62), line * 0.45);

  // you (erased inside the lens) over Spider-Man; all colours are premultiplied
  vec4 b = texture2D(uBase, vUv) * (1.0 - inside);
  vec4 r = texture2D(uReveal, vUv);
  vec4 col = b + r * inside * (1.0 - b.a); // Spider-Man only ever shows inside the lens
  gl_FragColor = vec4(rim * glow, glow) + col * (1.0 - glow);
}`

/** A looping S-curve across the portrait (0..1 coordinates) used for the intro / idle sweep. */
const sweepPath = (u) => ({
  x: 0.12 + 0.76 * u,
  y: 0.3 + 0.32 * u + 0.16 * Math.sin(u * Math.PI * 2.4),
})

let glSupport
/** Is WebGL available, with enough shader uniforms for the trail? (checked once) */
function supportsWebGL() {
  if (glSupport !== undefined) return glSupport
  try {
    const probe = document.createElement('canvas')
    const gl = probe.getContext('webgl')
    glSupport = !!gl && gl.getParameter(gl.MAX_FRAGMENT_UNIFORM_VECTORS) >= MAX_PTS + 8
    gl?.getExtension('WEBGL_lose_context')?.loseContext()
  } catch {
    glSupport = false
  }
  return glSupport
}

function compile(gl, type, src) {
  const sh = gl.createShader(type)
  gl.shaderSource(sh, src)
  gl.compileShader(sh)
  if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(sh))
  return sh
}

function makeTexture(gl, unit) {
  const tex = gl.createTexture()
  gl.activeTexture(gl.TEXTURE0 + unit)
  gl.bindTexture(gl.TEXTURE_2D, tex)
  gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true)
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE)
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE)
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR)
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR)
  return tex
}

/** Upload `img` to `unit`, first shrinking it (with the browser's high-quality resampler) to `w` px wide. */
function upload(gl, unit, tex, img, w) {
  let src = img
  if (w < img.naturalWidth * 0.9) {
    const c = document.createElement('canvas')
    c.width = Math.round(w)
    c.height = Math.round((w * img.naturalHeight) / img.naturalWidth)
    const cx = c.getContext('2d')
    cx.imageSmoothingQuality = 'high'
    cx.drawImage(img, 0, 0, c.width, c.height)
    src = c
  }
  gl.activeTexture(gl.TEXTURE0 + unit)
  gl.bindTexture(gl.TEXTURE_2D, tex)
  gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true)
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src)
}

const loadImage = (src) =>
  new Promise((resolve, reject) => {
    const img = new Image()
    img.onload = () => resolve(img)
    img.onerror = reject
    img.src = src
  })

function PortraitRevealGL({ base, reveal, baseAlt, width, height, onFail }) {
  const wrapRef = useRef(null)
  const canvasRef = useRef(null)
  const [ready, setReady] = useState(false)
  const [touched, setTouched] = useState(false)

  useEffect(() => {
    const wrap = wrapRef.current
    const canvas = canvasRef.current
    if (!wrap || !canvas) return undefined

    const ASPECT = height / width
    let gl
    let uPts
    let uCssW
    try {
      gl = canvas.getContext('webgl', { alpha: true, premultipliedAlpha: true, antialias: false })
      if (!gl) throw new Error('no webgl')
      const prog = gl.createProgram()
      gl.attachShader(prog, compile(gl, gl.VERTEX_SHADER, VERT))
      gl.attachShader(prog, compile(gl, gl.FRAGMENT_SHADER, FRAG))
      gl.linkProgram(prog)
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog))
      gl.useProgram(prog)

      const buf = gl.createBuffer()
      gl.bindBuffer(gl.ARRAY_BUFFER, buf)
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW)
      const aPos = gl.getAttribLocation(prog, 'aPos')
      gl.enableVertexAttribArray(aPos)
      gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0)

      uPts = gl.getUniformLocation(prog, 'uPts')
      uCssW = gl.getUniformLocation(prog, 'uCssW')
      gl.uniform1f(gl.getUniformLocation(prog, 'uAspect'), ASPECT)
      gl.uniform3fv(gl.getUniformLocation(prog, 'uGold'), GOLD)
      gl.uniform1i(gl.getUniformLocation(prog, 'uBase'), 0)
      gl.uniform1i(gl.getUniformLocation(prog, 'uReveal'), 1)
      gl.clearColor(0, 0, 0, 0)
    } catch {
      onFail()
      return undefined
    }

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const coarse = window.matchMedia('(hover: none), (pointer: coarse)').matches

    // lens head: a spring chasing the pointer
    const s = { x: 0.5, y: 0.4 * ASPECT, vx: 0, vy: 0, tx: 0.5, ty: 0.4 * ASPECT, over: false }
    let head = 0 // 0..1, how present the lens is (eases in on enter, out on leave)
    let speedN = 0 // smoothed 0..1 speed, makes the lens swell a little when flicked
    let trail = [] // { x, y, r, born, seed }, newest last
    let lastEmit = null
    const data = new Float32Array(MAX_PTS * 4)

    let raf = 0
    let prev = 0
    let alive = true
    let visible = true
    let sweeping = false
    let lastInput = performance.now()

    const texBase = makeTexture(gl, 0)
    const texReveal = makeTexture(gl, 1)
    let imgs = null // [base, reveal] once loaded
    let texW = 0 // width the textures were last uploaded at

    const fit = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2)
      const w = Math.max(1, Math.round(wrap.clientWidth * dpr))
      const h = Math.max(1, Math.round(wrap.clientHeight * dpr))
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w
        canvas.height = h
      }
      gl.viewport(0, 0, w, h)
      gl.uniform1f(uCssW, wrap.clientWidth)
      if (!imgs) return // nothing to draw until the photos are in
      if (!texW || Math.abs(w - texW) / texW > 0.12) {
        texW = w
        upload(gl, 0, texBase, imgs[0], w)
        upload(gl, 1, texReveal, imgs[1], w)
      }
      draw(performance.now())
    }

    function draw(now) {
      const t = now / 1000
      data.fill(0)
      let n = 0
      if (head > 0.004) {
        const hr = R * (0.18 + 0.82 * head) * (1 + 0.14 * speedN)
        data.set([s.x, s.y, hr, 1], 0)
        n = 1
      }
      for (let i = trail.length - 1; i >= 0 && n < MAX_PTS; i -= 1) {
        const p = trail[i]
        const age = Math.min(1, (now - p.born) / 1000 / LIFE)
        const wobble = 1 + 0.07 * Math.sin(t * 5 + p.seed)
        // a tail that tapers to a point as it heals
        const r = p.r * wobble * (1 - 0.9 * age ** 0.85)
        data.set([p.x, p.y, r, 1 - 0.3 * age], n * 4)
        n += 1
      }
      gl.uniform4fv(uPts, data)
      gl.clear(gl.COLOR_BUFFER_BIT)
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4)
    }

    const emit = (now, hr) => {
      if (!lastEmit) {
        lastEmit = { x: s.x, y: s.y }
        return
      }
      const dx = s.x - lastEmit.x
      const dy = s.y - lastEmit.y
      const dist = Math.hypot(dx, dy)
      const n = Math.min(10, Math.floor(dist / SPACING))
      for (let i = 1; i <= n; i += 1) {
        const k = (i * SPACING) / dist
        trail.push({
          x: lastEmit.x + dx * k,
          y: lastEmit.y + dy * k,
          r: hr * 0.96,
          born: now,
          seed: Math.random() * 6.28,
        })
      }
      if (n > 0) {
        const k = (n * SPACING) / dist
        lastEmit = { x: lastEmit.x + dx * k, y: lastEmit.y + dy * k }
      }
      if (trail.length > MAX_PTS - 1) trail = trail.slice(-(MAX_PTS - 1))
    }

    function frame(now) {
      raf = 0
      if (!alive) return
      const dt = Math.min(Math.max((now - prev) / 1000, 0), 1 / 20)
      prev = now

      // spring physics, in small fixed steps so it stays stable at any frame rate
      const steps = Math.max(1, Math.ceil(dt * 120))
      const h = dt / steps
      for (let i = 0; i < steps; i += 1) {
        s.vx += ((s.tx - s.x) * STIFFNESS - s.vx * DAMPING) * h
        s.vy += ((s.ty - s.y) * STIFFNESS - s.vy * DAMPING) * h
        s.x += s.vx * h
        s.y += s.vy * h
      }

      const goal = s.over ? 1 : 0
      head += (goal - head) * (1 - Math.exp(-dt * (goal ? 16 : 7)))
      if (!s.over && head < 0.004) head = 0
      const speed = Math.hypot(s.vx, s.vy)
      speedN += (Math.min(speed / 1.6, 1) - speedN) * (1 - Math.exp(-dt * 9))

      if (head > 0.02) emit(now, R * (0.18 + 0.82 * head) * (1 + 0.14 * speedN))
      else lastEmit = null
      trail = trail.filter((p) => now - p.born < LIFE * 1000)

      draw(now)
      if (s.over || head > 0 || trail.length) start()
    }
    function start() {
      if (!raf && alive) {
        prev = prev || performance.now()
        raf = requestAnimationFrame(frame)
      }
    }
    const sleepReset = () => {
      if (!raf) prev = 0
    }

    const setTarget = (e) => {
      const b = wrap.getBoundingClientRect()
      s.tx = (e.clientX - b.left) / b.width
      s.ty = ((e.clientY - b.top) / b.height) * ASPECT
    }
    const onMove = (e) => {
      sweeping = false // a real pointer takes over from any scripted sweep
      setTarget(e)
      if (!s.over) {
        s.over = true
        if (head < 0.05) {
          s.x = s.tx
          s.y = s.ty
          s.vx = 0
          s.vy = 0
          lastEmit = null
        }
      }
      lastInput = performance.now()
      setTouched(true)
      sleepReset()
      start()
    }
    const onLeave = () => {
      s.over = false
      start()
    }
    const onUp = (e) => {
      if (e.pointerType !== 'mouse') onLeave()
    }

    /** Scripted brush stroke (intro + idle sweep on touch screens). */
    const sweep = () => {
      if (sweeping || reduced || s.over) return
      const t0 = performance.now()
      const dur = 1800
      sweeping = true
      const p0 = sweepPath(0)
      s.x = s.tx = p0.x
      s.y = s.ty = p0.y * ASPECT
      s.vx = 0
      s.vy = 0
      s.over = true
      lastEmit = null
      sleepReset()
      const step = (now) => {
        if (!sweeping || !alive) return
        const u = Math.min(1, (now - t0) / dur)
        const p = sweepPath(u * u * (3 - 2 * u))
        s.tx = p.x
        s.ty = p.y * ASPECT
        if (u < 1) requestAnimationFrame(step)
        else {
          sweeping = false
          s.over = false
        }
        start()
      }
      requestAnimationFrame(step)
      start()
    }

    wrap.addEventListener('pointermove', onMove)
    wrap.addEventListener('pointerdown', onMove)
    wrap.addEventListener('pointerleave', onLeave)
    wrap.addEventListener('pointerup', onUp)
    wrap.addEventListener('pointercancel', onLeave)
    canvas.addEventListener('webglcontextlost', onFail)

    const ro = new ResizeObserver(fit)
    ro.observe(wrap)
    const io = new IntersectionObserver(([en]) => {
      visible = en.isIntersecting
    })
    io.observe(wrap)

    let sweepTimer = 0
    Promise.all([loadImage(base), loadImage(reveal)])
      .then((loaded) => {
        if (!alive) return
        imgs = loaded
        fit()
        setReady(true)
        if (!reduced) sweepTimer = setTimeout(sweep, 1400) // so visitors see what the portrait does
      })
      .catch(onFail)

    const idle = coarse
      ? setInterval(() => {
          if (visible && !document.hidden && performance.now() - lastInput > 3500) sweep()
        }, 4200)
      : 0

    return () => {
      alive = false
      cancelAnimationFrame(raf)
      clearTimeout(sweepTimer)
      clearInterval(idle)
      ro.disconnect()
      io.disconnect()
      wrap.removeEventListener('pointermove', onMove)
      wrap.removeEventListener('pointerdown', onMove)
      wrap.removeEventListener('pointerleave', onLeave)
      wrap.removeEventListener('pointerup', onUp)
      wrap.removeEventListener('pointercancel', onLeave)
      canvas.removeEventListener('webglcontextlost', onFail)
    }
  }, [base, reveal, width, height, onFail])

  return (
    <div ref={wrapRef} className={styles.wrap} style={{ aspectRatio: `${width} / ${height}` }}>
      {/* the canvas takes over once ready; this image is the no-JS / loading state */}
      <img
        className={styles.layer}
        src={base}
        width={width}
        height={height}
        alt={baseAlt}
        fetchPriority="high"
        style={{ opacity: ready ? 0 : 1 }}
      />
      <canvas ref={canvasRef} className={styles.canvas} aria-hidden="true" />
      <span className={styles.hint} data-gone={touched} aria-hidden="true">
        Move over me
      </span>
    </div>
  )
}

export default function PortraitReveal({ width = 800, height = 1200, ...props }) {
  const [useCanvas, setUseCanvas] = useState(() => !supportsWebGL())
  const fail = useRef(() => setUseCanvas(true)).current
  return useCanvas ? (
    <PortraitRevealCanvas width={width} height={height} {...props} />
  ) : (
    <PortraitRevealGL width={width} height={height} onFail={fail} {...props} />
  )
}
