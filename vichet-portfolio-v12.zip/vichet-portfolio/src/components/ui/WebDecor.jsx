import { cn } from '@/utils/cn'
import Web from './Web'
import styles from './WebDecor.module.css'

/**
 * A web pinned to a corner of its section that drifts slowly as the page scrolls.
 * position: 'tl' | 'tr' | 'bl' | 'br'
 */
export default function WebDecor({ position = 'tl', size = 240 }) {
  return (
    <div className={cn(styles.decor, styles[position])} style={{ '--size': `${size}px` }}>
      <Web className={styles.web} />
    </div>
  )
}
