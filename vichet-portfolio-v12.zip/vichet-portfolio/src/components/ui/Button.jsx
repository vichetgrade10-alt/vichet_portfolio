import { cn } from '@/utils/cn'
import Icon from './Icon'
import styles from './Button.module.css'

/**
 * Renders an <a> when `href` is given, otherwise a <button>.
 * variant: 'primary' (red) | 'secondary' (navy) | 'ghost' (outline)
 */
export default function Button({
  href,
  variant = 'primary',
  icon,
  external = false,
  pulse = false,
  className,
  children,
  ...rest
}) {
  const classes = cn(styles.btn, styles[variant], pulse && styles.pulse, className)
  const content = (
    <>
      <span>{children}</span>
      {icon && <Icon name={icon} size={16} />}
    </>
  )

  if (href) {
    return (
      <a
        className={classes}
        href={href}
        {...(external && { target: '_blank', rel: 'noopener noreferrer' })}
        {...rest}
      >
        {content}
      </a>
    )
  }
  return (
    <button className={classes} type="button" {...rest}>
      {content}
    </button>
  )
}
