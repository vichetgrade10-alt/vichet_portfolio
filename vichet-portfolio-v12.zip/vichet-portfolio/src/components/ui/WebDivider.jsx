import { useEffect, useRef, useState } from 'react'
import { useInView, usePrefersReducedMotion } from '@/hooks'
import { cn } from '@/utils/cn'
import Spider from './Spider'
import styles from './WebDivider.module.css'

const VIEW_W = 1440
const VIEW_H = 80
const WALK_MS = 9000 // time to cross the page
const REST_MS = 1800 // pause at each end
const START_DELAY = 1500 // let the strand finish drawing first
const MAIN_STRAND = 'M0 40 C 240 -6, 480 86, 720 40 S 1200 -6, 1440 40'
const SECOND_STRAND = 'M0 46 C 260 94, 520 -2, 760 46 S 1180 94, 1440 38'

const easeInOut = (t) => 0.5 - Math.cos(Math.PI * t) / 2

/**
 * Two thin web strands that draw themselves across the page between sections,
 * with a small spider that walks along the upper strand while the divider is on screen.
 *
 * The SVG is stretched to the page width, so the spider is placed with JavaScript
 * (reading points off the real path and scaling x to the container) instead of being
 * stretched along with it.
 */
export default function WebDivider({ flip = false }) {
  const [ref, inView] = useInView({ threshold: 0.6, rootMargin: '0px', once: false })
  const [drawn, setDrawn] = useState(false)
  const pathRef = useRef(null)
  const spiderRef = useRef(null)
  const reduced = usePrefersReducedMotion()

  // Draw the strands the first time they appear and keep them drawn afterwards.
  useEffect(() => {
    if (inView) setDrawn(true)
  }, [inView])

  // Walk back and forth along the strand, only while the divider is visible.
  useEffect(() => {
    const path = pathRef.current
    const spider = spiderRef.current
    const box = ref.current
    if (!inView || reduced || !path || !spider || !box) return undefined

    const length = path.getTotalLength()
    const startedAt = performance.now() + START_DELAY
    const cycle = 2 * (WALK_MS + REST_MS)
    let frame = 0

    const place = (progress, direction) => {
      const scaleX = box.clientWidth / VIEW_W
      const here = path.getPointAtLength(progress * length)
      const ahead = path.getPointAtLength(
        Math.min(Math.max(progress * length + direction * 2, 0), length),
      )
      // Head points "up" in the artwork, so rotate by the travel angle + 90°.
      const angle = (Math.atan2(ahead.y - here.y, (ahead.x - here.x) * scaleX) * 180) / Math.PI + 90
      spider.style.transform = `translate(${here.x * scaleX}px, ${here.y}px) translate(-50%, -50%) rotate(${angle}deg)`
    }

    const tick = (now) => {
      const t = now - startedAt
      if (t >= 0) {
        const phase = t % cycle
        if (phase < WALK_MS) place(easeInOut(phase / WALK_MS), 1)
        else if (phase < WALK_MS + REST_MS) place(1, 1)
        else if (phase < 2 * WALK_MS + REST_MS) {
          place(1 - easeInOut((phase - WALK_MS - REST_MS) / WALK_MS), -1)
        } else place(0, -1)
        spider.style.opacity = '1'
      }
      frame = requestAnimationFrame(tick)
    }
    frame = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(frame)
  }, [inView, reduced, ref])

  return (
    <div
      ref={ref}
      className={cn(styles.divider, flip && styles.flip, drawn && styles.in)}
      aria-hidden="true"
    >
      <svg viewBox={`0 0 ${VIEW_W} ${VIEW_H}`} preserveAspectRatio="none" fill="none">
        <path ref={pathRef} className={styles.strand} pathLength="1" d={MAIN_STRAND} />
        <path className={cn(styles.strand, styles.second)} pathLength="1" d={SECOND_STRAND} />
      </svg>
      <div ref={spiderRef} className={styles.walker}>
        <Spider size={30} />
      </div>
    </div>
  )
}
