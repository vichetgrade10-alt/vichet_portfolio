import { useCallback, useEffect, useState } from 'react'
import { profile } from '@/data'
import { cn } from '@/utils/cn'
import Spider from './Spider'
import Web from './Web'
import styles from './Intro.module.css'

const HOLD = 2300 // ms the intro plays before sliding away
const EXIT = 850 // ms of the slide-away animation

/**
 * One-time intro: a web draws itself, the mascot drops in on its thread and the name appears,
 * then the whole screen lifts away. Plays once per browser session; click or Esc skips it.
 * index.html sets data-intro="on" on <html> before first paint; we clear it when done,
 * which also releases the hero animations that were held back behind the overlay.
 */
export default function Intro() {
  const [phase, setPhase] = useState(() =>
    document.documentElement.dataset.intro === 'on' ? 'play' : 'done',
  )

  const finish = useCallback(() => {
    setPhase((current) => (current === 'play' ? 'leave' : current))
    document.documentElement.removeAttribute('data-intro')
    try {
      sessionStorage.setItem('intro-seen', '1')
    } catch {
      /* storage blocked - the intro just plays again next visit */
    }
  }, [])

  useEffect(() => {
    if (phase !== 'play') return undefined
    const timer = setTimeout(finish, HOLD)
    const onKey = (e) => e.key === 'Escape' && finish()
    window.addEventListener('keydown', onKey)
    return () => {
      clearTimeout(timer)
      window.removeEventListener('keydown', onKey)
    }
  }, [phase, finish])

  useEffect(() => {
    if (phase !== 'leave') return undefined
    const timer = setTimeout(() => setPhase('done'), EXIT)
    return () => clearTimeout(timer)
  }, [phase])

  if (phase === 'done') return null

  const letters = [...profile.name.toUpperCase()]

  return (
    <div
      className={cn(styles.intro, phase === 'leave' && styles.leave)}
      onClick={finish}
      aria-hidden="true"
    >
      <Web className={styles.web} />

      <div className={styles.dropWrap}>
        <div className={styles.dropper}>
          <span className={styles.thread} />
          <Spider size={84} className={styles.spider} />
        </div>
      </div>

      <div className={styles.text}>
        <p className={styles.name}>
          {letters.map((char, i) => (
            <span key={i} className={styles.char} style={{ '--i': i }}>
              {char === ' ' ? ' ' : char}
            </span>
          ))}
        </p>
        <p className={styles.tagline}>{profile.tagline}</p>
      </div>

      <span className={styles.bar} />
      <span className={styles.skip}>Click to skip</span>
    </div>
  )
}
