import styles from './ScrollProgress.module.css'

/** Thin red bar at the very top that fills as you scroll (driven by the --progress CSS variable). */
export default function ScrollProgress() {
  return <div className={styles.bar} aria-hidden="true" />
}
