import { profile } from '@/data'
import Icon from '@/components/ui/Icon'
import styles from './Footer.module.css'

export default function Footer() {
  return (
    <footer className={styles.footer}>
      <p>
        © {new Date().getFullYear()} {profile.name} · Built with a little web-slinging
      </p>
      <a href="#home" className={styles.top}>
        Back to top <Icon name="arrowUp" size={14} />
      </a>
    </footer>
  )
}
