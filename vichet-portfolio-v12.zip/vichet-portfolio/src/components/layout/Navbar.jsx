import { useEffect, useState } from 'react'
import { navItems, profile } from '@/data'
import { useScrollSpy } from '@/hooks'
import Icon from '@/components/ui/Icon'
import { cn } from '@/utils/cn'
import ThemeToggle from './ThemeToggle'
import styles from './Navbar.module.css'

const SECTION_IDS = navItems.map((item) => item.id)

export default function Navbar() {
  const active = useScrollSpy(SECTION_IDS)
  const [open, setOpen] = useState(false)
  const close = () => setOpen(false)

  // Close the mobile menu with Escape.
  useEffect(() => {
    if (!open) return undefined
    const onKey = (e) => e.key === 'Escape' && setOpen(false)
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open])

  return (
    <header className={styles.header}>
      <nav className={styles.nav} aria-label="Primary">
        <a
          href="#home"
          className={styles.logo}
          onClick={close}
          aria-label={`${profile.name} - home`}
        >
          {profile.initials}
        </a>

        <ul id="nav-links" className={cn(styles.links, open && styles.open)}>
          {navItems.map(({ id, label }) => (
            <li key={id}>
              <a
                href={`#${id}`}
                className={cn(styles.link, active === id && styles.active)}
                aria-current={active === id ? 'true' : undefined}
                onClick={close}
              >
                {label}
              </a>
            </li>
          ))}
        </ul>

        <div className={styles.actions}>
          <ThemeToggle />
          <button
            type="button"
            className={styles.burger}
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="nav-links"
            aria-label={open ? 'Close menu' : 'Open menu'}
          >
            <Icon name={open ? 'close' : 'menu'} size={20} />
          </button>
        </div>
      </nav>
    </header>
  )
}
