import { profile, projects, skills } from '@/data'
import { usePointerParallax, useRotatingText } from '@/hooks'
import Button from '@/components/ui/Button'
import InteractiveWeb from '@/components/ui/InteractiveWeb'
import Web from '@/components/ui/Web'
import WebDecor from '@/components/ui/WebDecor'
import PortraitReveal from '@/components/ui/PortraitReveal'
import portraitMe from '@/assets/portrait-me.webp'
import portraitSpider from '@/assets/portrait-spider.webp'
import styles from './Hero.module.css'

const nameParts = profile.name.split(' ')

export default function Hero() {
  const stageRef = usePointerParallax()
  const role = useRotatingText(profile.roles)

  const stats = [
    { value: projects.length, label: projects.length === 1 ? 'Project' : 'Projects' },
    { value: skills.length, label: 'Core skills' },
  ]

  return (
    <section id="home" className={styles.hero} aria-labelledby="hero-title">
      <InteractiveWeb />
      <WebDecor position="tl" size={220} />

      <div className={styles.copy}>
        <span className={styles.tagline}>{profile.tagline}</span>

        <h1 id="hero-title" className={styles.title}>
          {nameParts.map((part, i) => (
            <span key={part} className={styles.word} style={{ '--i': i }}>
              {part}
              {i === nameParts.length - 1 && '.'}
            </span>
          ))}
        </h1>

        <p className={styles.role} aria-live="off">
          <span className={styles.roleLabel}>Focused on</span>
          <span key={role.index} className={styles.roleText}>
            {role.text}
          </span>
        </p>

        <p className={styles.intro}>{profile.intro}</p>

        <p className={styles.open}>
          <span className={styles.dot} aria-hidden="true" />
          <strong>Open to work</strong>
          <span className={styles.openList}>{profile.openTo.slice(0, 3).join(' · ')}</span>
        </p>

        <div className={styles.actions}>
          <Button href="#projects" variant="primary" icon="arrow">
            Explore Projects
          </Button>
          <Button href="#contact" variant="secondary">
            Contact Me
          </Button>
        </div>

        <dl className={styles.stats}>
          {stats.map((s) => (
            <div key={s.label}>
              <dt>{s.label}</dt>
              <dd>{s.value}</dd>
            </div>
          ))}
        </dl>
      </div>

      <div className={styles.portraitWrap}>
        {/* Layers shift by different amounts as the pointer moves (parallax). No overlays, no tint. */}
        <div className={styles.stage} ref={stageRef}>
          <div className={styles.dots} aria-hidden="true" />
          <Web className={styles.cornerWeb} />
          <PortraitReveal
            base={portraitMe}
            reveal={portraitSpider}
            baseAlt={`Portrait of ${profile.name}`}
          />
        </div>
      </div>
    </section>
  )
}
