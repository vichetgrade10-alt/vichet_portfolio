import { profile } from '@/data'
import Button from '@/components/ui/Button'
import Reveal from '@/components/ui/Reveal'
import Section from '@/components/ui/Section'
import SectionHeading from '@/components/ui/SectionHeading'
import Spider from '@/components/ui/Spider'
import WebDecor from '@/components/ui/WebDecor'
import styles from './Contact.module.css'

export default function Contact() {
  const { email, socials } = profile

  return (
    <Section id="contact" labelledBy="contact-title" className={styles.contact}>
      <div className={styles.thread} aria-hidden="true">
        <Spider size={46} className={styles.hang} />
      </div>
      <WebDecor position="bl" size={240} />

      <SectionHeading id="contact-title" eyebrow="Say hello" title="Contact." align="center" />

      <Reveal delay={100}>
        <p className={styles.lead}>Got an idea or an opportunity? Let’s swing into it.</p>

        <ul className={styles.badges} aria-label="Open to">
          {profile.openTo.map((item) => (
            <li key={item} className={styles.badge}>
              <span className={styles.dot} aria-hidden="true" />
              Open to {item.toLowerCase()}
            </li>
          ))}
        </ul>

        <div className={styles.actions}>
          <Button href={`mailto:${email}`} variant="primary" icon="mail" pulse>
            Email me
          </Button>
          <Button href={socials.linkedin} variant="secondary" icon="linkedin" external>
            LinkedIn
          </Button>
          <Button href={socials.github} variant="secondary" icon="github" external>
            GitHub
          </Button>
          <Button href={socials.facebook} variant="secondary" icon="facebook" external>
            Facebook
          </Button>
        </div>

        <p className={styles.email}>
          <a href={`mailto:${email}`}>{email}</a>
        </p>
      </Reveal>
    </Section>
  )
}
