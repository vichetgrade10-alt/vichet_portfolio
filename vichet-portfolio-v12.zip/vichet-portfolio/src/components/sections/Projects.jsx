import { lazy, Suspense, useState } from 'react'
import { projects } from '@/data'
import Modal from '@/components/ui/Modal'
import Reveal from '@/components/ui/Reveal'
import Section from '@/components/ui/Section'
import SectionHeading from '@/components/ui/SectionHeading'
import WebDecor from '@/components/ui/WebDecor'
import ProjectCard from './ProjectCard'
import styles from './Projects.module.css'

// The dashboard (and the chart library behind it) is a separate file that only downloads when needed.
const loadDashboard = () => import('@/components/dashboard/EvDashboard')
const EvDashboard = lazy(loadDashboard)

const DASHBOARDS = {
  'ev-adoption': {
    Component: EvDashboard,
    title: 'EV Sales & Adoption',
    subtitle: 'Interactive version of my Power BI report. Filter by region and brand.',
  },
}

export default function Projects() {
  const [openId, setOpenId] = useState(null)
  const dashboard = DASHBOARDS[openId]

  return (
    <Section id="projects" labelledBy="projects-title">
      <WebDecor position="tr" size={240} />
      <SectionHeading id="projects-title" eyebrow="Featured work" title="Projects." />

      <ul className={styles.grid}>
        {projects.map((project, i) => (
          <Reveal as="li" key={project.id} delay={i * 120} className={styles.item}>
            <ProjectCard
              index={i}
              {...project}
              onOpen={project.dashboard ? () => setOpenId(project.dashboard) : undefined}
              onWarm={project.dashboard ? loadDashboard : undefined}
            />
          </Reveal>
        ))}
      </ul>

      <Modal
        open={Boolean(dashboard)}
        onClose={() => setOpenId(null)}
        title={dashboard?.title ?? ''}
        subtitle={dashboard?.subtitle}
      >
        {dashboard && (
          <Suspense fallback={<p className={styles.loading}>Loading dashboard…</p>}>
            <dashboard.Component />
          </Suspense>
        )}
      </Modal>
    </Section>
  )
}
