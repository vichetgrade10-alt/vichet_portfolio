import { dataTools } from '@/data'
import { useInView, useTilt } from '@/hooks'
import Section from '@/components/ui/Section'
import SectionHeading from '@/components/ui/SectionHeading'
import { cn } from '@/utils/cn'
import styles from './Skills.module.css'

export default function Skills() {
  const [toolRef, toolIn] = useInView({ threshold: 0.3 })
  const tiltRef = useTilt(3)

  return (
    <Section id="skills" labelledBy="skills-title">
      <SectionHeading id="skills-title" eyebrow="Arsenal & expertise" title="Skills." />

      <div ref={toolRef} className={cn(styles.toolkit, toolIn && styles.toolIn)}>
        <div ref={tiltRef} className={styles.toolkitInner}>
          <span className={styles.shine} aria-hidden="true" />
          <span className={styles.kicker}>Data</span>
          <h3 className={styles.toolkitTitle}>Data Analysis</h3>
          <p className={styles.toolkitText}>
            Turning messy datasets into clear narratives: dashboards, statistical analysis and
            visualisations that support real decisions.
          </p>
          <ul className={styles.chips}>
            {dataTools.map((tool, i) => (
              <li key={tool.name} className={styles.chip} style={{ '--i': i }}>
                <span className={styles.mark} style={{ '--hue': tool.hue }} aria-hidden="true">
                  {tool.mark}
                </span>
                {tool.name}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Section>
  )
}
