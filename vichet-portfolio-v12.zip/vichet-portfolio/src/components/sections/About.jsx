import { profile } from '@/data'
import Reveal from '@/components/ui/Reveal'
import Section from '@/components/ui/Section'
import SectionHeading from '@/components/ui/SectionHeading'
import WebDecor from '@/components/ui/WebDecor'
import cutout from '@/assets/vichet-cutout.webp'
import styles from './About.module.css'

export default function About() {
  return (
    <Section id="about" labelledBy="about-title">
      <WebDecor position="tl" size={260} />

      <div className={styles.layout}>
        <div className={styles.text}>
          <SectionHeading id="about-title" eyebrow="Behind the mask" title={`${profile.name}.`} />

          {profile.about.map((paragraph, i) => (
            <Reveal as="p" key={paragraph} delay={100 + i * 100} className={styles.paragraph}>
              {paragraph}
            </Reveal>
          ))}

          <ul className={styles.highlights}>
            {profile.highlights.map((item, i) => (
              <Reveal as="li" key={item.label} delay={250 + i * 100} className={styles.highlight}>
                <span className={styles.label}>{item.label}</span>
                <span className={styles.value}>{item.value}</span>
              </Reveal>
            ))}
          </ul>
        </div>

        {/* One silk thread from a nail: the whole frame swings from it, and a small spider rides the thread. */}
        <Reveal delay={200} className={styles.hanger}>
          <span className={styles.nail} aria-hidden="true" />
          <div className={styles.swing}>
            <svg
              className={styles.thread}
              viewBox="0 0 4 120"
              preserveAspectRatio="none"
              aria-hidden="true"
            >
              <line x1="2" y1="0" x2="2" y2="120" pathLength="1" />
            </svg>
            <svg className={styles.rider} viewBox="0 0 24 24" aria-hidden="true">
              <g stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" fill="none">
                <path d="M9 11 4 6M9 13 3 13M9 15 4 20M8 12 5 9M15 11l5-5M15 13l6 0M15 15l5 5M16 12l3-3" />
              </g>
              <ellipse cx="12" cy="14" rx="4" ry="5" fill="currentColor" />
              <circle cx="12" cy="8.5" r="2.6" fill="currentColor" />
              <circle cx="11" cy="8" r=".7" fill="#fff" />
              <circle cx="13" cy="8" r=".7" fill="#fff" />
            </svg>
            <div className={styles.ring}>
              <div className={styles.frame}>
                <div className={styles.dots} aria-hidden="true" />
                <img src={cutout} width="720" height="840" alt={profile.name} loading="lazy" />
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </Section>
  )
}
