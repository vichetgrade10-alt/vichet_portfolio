import { profile } from '@/data'
import styles from './Marquee.module.css'

const SEPARATOR = ' ✦ '

const makeLine = (items) => items.join(SEPARATOR).toUpperCase() + SEPARATOR

/** Two tilted ribbons scrolling in opposite directions. Purely decorative. */
export default function Marquee() {
  const lineA = makeLine(profile.ribbon)
  const lineB = makeLine([profile.name, 'Open to work'])

  return (
    <div className={styles.ribbons} aria-hidden="true">
      <Ribbon text={lineA} className={styles.a} />
      <Ribbon text={lineB} className={styles.b} reverse />
    </div>
  )
}

function Ribbon({ text, className, reverse = false }) {
  // Two identical halves so translating by -50% loops seamlessly.
  const half = text.repeat(6)
  return (
    <div className={`${styles.ribbon} ${className}`}>
      <div className={styles.track} data-reverse={reverse}>
        <span>{half}</span>
        <span>{half}</span>
      </div>
    </div>
  )
}
