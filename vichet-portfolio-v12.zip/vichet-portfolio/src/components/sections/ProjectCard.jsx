import { useState } from 'react'
import Sparkline from '@/components/ui/Sparkline'
import Icon from '@/components/ui/Icon'
import { formatInt, formatMoney, formatPercent } from '@/utils/format'
import { cn } from '@/utils/cn'
import styles from './ProjectCard.module.css'

/** The thumbnail: a live mini-dashboard, a screenshot carousel, or a placeholder. */
function Media({ index, title, images = [], summary }) {
  const [slide, setSlide] = useState(0)
  const go = (step) => (e) => {
    e.stopPropagation()
    setSlide((s) => (s + step + images.length) % images.length)
  }

  return (
    <div className={styles.media}>
      {summary ? (
        <div className={styles.live} aria-label="Dashboard preview">
          <dl className={styles.stats}>
            <div>
              <dt>Revenue</dt>
              <dd>{formatMoney(summary.revenue)}</dd>
            </div>
            <div>
              <dt>Units</dt>
              <dd>{formatInt(summary.units)}</dd>
            </div>
            <div>
              <dt>Discount</dt>
              <dd>{formatPercent(summary.avgDiscount, 1)}</dd>
            </div>
          </dl>
          <Sparkline values={summary.monthlyRevenue} />
        </div>
      ) : images.length > 0 ? (
        <>
          {images.map((src, i) => (
            <img
              key={src}
              className={cn(styles.shot, i === slide && styles.active)}
              src={src}
              alt={i === slide ? `${title} screenshot ${i + 1}` : ''}
              loading="lazy"
            />
          ))}
          {images.length > 1 && (
            <>
              <button
                type="button"
                className={cn(styles.nav, styles.prev)}
                onClick={go(-1)}
                aria-label="Previous image"
              >
                <Icon name="arrow" size={16} />
              </button>
              <button
                type="button"
                className={cn(styles.nav, styles.next)}
                onClick={go(1)}
                aria-label="Next image"
              >
                <Icon name="arrow" size={16} />
              </button>
            </>
          )}
        </>
      ) : (
        <div className={styles.placeholder} aria-hidden="true">
          <span>{String(index + 1).padStart(2, '0')}</span>
        </div>
      )}
    </div>
  )
}

/** Card: thumbnail, title, description, tag pills, then a row of links. */
export default function ProjectCard({
  index,
  title,
  description,
  tags = [],
  links = [],
  images,
  summary,
  onOpen,
  onWarm,
}) {
  return (
    <article
      className={cn(styles.card, onOpen && styles.clickable)}
      onClick={onOpen}
      onPointerEnter={onWarm}
      onFocus={onWarm}
    >
      <Media index={index} title={title} images={images} summary={summary} />

      <h3 className={styles.title}>{title}</h3>
      <p className={styles.description}>{description}</p>

      <ul className={styles.tags}>
        {tags.map((tag) => (
          <li key={tag}>{tag}</li>
        ))}
      </ul>

      <div className={styles.links}>
        {links.map((l) =>
          l.href ? (
            <a
              key={l.label}
              href={l.href}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()}
            >
              {l.label}
            </a>
          ) : (
            <button key={l.label} type="button" onClick={onOpen}>
              {l.label}
            </button>
          ),
        )}
      </div>
    </article>
  )
}
