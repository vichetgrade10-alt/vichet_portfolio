import { useCallback, useMemo, useState } from 'react'
import sales from '@/data/ev/evSales.json'
import { computeKpis, distinct, filterRows } from '@/utils/evAnalytics'
import { formatInt } from '@/utils/format'
import { cn } from '@/utils/cn'
import { createColorScale } from './palette'
import DeepDiveTab from './DeepDiveTab'
import FilterRail from './FilterRail'
import OverviewTab from './OverviewTab'
import styles from './EvDashboard.module.css'

// Lists and colour scales are built once from the full dataset so they never change with the filters.
const REGIONS = distinct(sales, 'Region')
const BRANDS = distinct(sales, 'Brand')
const BENCHMARK = computeKpis(sales)
const brandColor = createColorScale(BRANDS)
const regionColor = createColorScale(REGIONS)
const vehicleColor = createColorScale(distinct(sales, 'Vehicle_Type'))
const segmentColor = createColorScale(distinct(sales, 'Customer_Segment'))

const TABS = [
  { id: 'overview', label: 'Overview' },
  { id: 'deep', label: 'Deep dive' },
]

/** Interactive recreation of the "EV Adoption" Power BI report (2 pages + Region / Brand slicers). */
export default function EvDashboard() {
  const [tab, setTab] = useState('overview')
  const [selected, setSelected] = useState({ regions: [], brands: [] })

  const toggle = useCallback((group, value) => {
    setSelected((s) => ({
      ...s,
      [group]: s[group].includes(value)
        ? s[group].filter((v) => v !== value)
        : [...s[group], value],
    }))
  }, [])
  const clear = useCallback(() => setSelected({ regions: [], brands: [] }), [])

  const rows = useMemo(() => filterRows(sales, selected), [selected])
  const kpis = useMemo(() => computeKpis(rows), [rows])

  return (
    <div className={styles.dashboard}>
      <FilterRail
        regions={REGIONS}
        brands={BRANDS}
        selected={selected}
        onToggle={toggle}
        onClear={clear}
        count={formatInt(rows.length)}
        total={formatInt(sales.length)}
      />

      <div className={styles.main}>
        <div className={styles.tabs} role="tablist" aria-label="Dashboard pages">
          {TABS.map(({ id, label }) => (
            <button
              key={id}
              type="button"
              role="tab"
              id={`ev-tab-${id}`}
              aria-selected={tab === id}
              aria-controls="ev-panel"
              className={cn(styles.tab, tab === id && styles.active)}
              onClick={() => setTab(id)}
            >
              {label}
            </button>
          ))}
          <span className={styles.source}>Source: EV sales dataset · built in Power BI · 2023</span>
        </div>

        <div
          id="ev-panel"
          role="tabpanel"
          aria-labelledby={`ev-tab-${tab}`}
          className={styles.panel}
        >
          {rows.length === 0 ? (
            <p className={styles.empty}>
              No records match this combination of filters.
              <button type="button" onClick={clear}>
                Clear filters
              </button>
            </p>
          ) : tab === 'overview' ? (
            <OverviewTab rows={rows} kpis={kpis} benchmark={BENCHMARK} brandColor={brandColor} />
          ) : (
            <DeepDiveTab
              rows={rows}
              regionColor={regionColor}
              vehicleColor={vehicleColor}
              segmentColor={segmentColor}
            />
          )}
        </div>
      </div>
    </div>
  )
}
