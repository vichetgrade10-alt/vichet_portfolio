import { formatMoney, formatPercent } from '@/utils/format'

/** Custom rectangle for the Treemap: coloured tile with the segment name and its revenue share. */
export default function TreemapNode({ x, y, width, height, name, value, depth, colorOf, total }) {
  if (depth < 1 || width <= 0 || height <= 0) return null
  const roomForText = width > 60 && height > 46
  // ~7px per character at this font size; shorten with an ellipsis instead of overflowing the tile
  const maxChars = Math.max(Math.floor((width - 20) / 7.4), 3)
  const label = name.length > maxChars ? `${name.slice(0, maxChars - 1)}…` : name
  const share = formatPercent((value / total) * 100, 0)

  return (
    <g>
      <rect
        x={x}
        y={y}
        width={width}
        height={height}
        rx={6}
        fill={colorOf(name)}
        stroke="var(--card-solid)"
        strokeWidth={3}
      />
      {roomForText && (
        <>
          <text x={x + 12} y={y + 24} fill="#fff" fontSize={13} fontWeight={800}>
            {label}
          </text>
          <text x={x + 12} y={y + 43} fill="#fff" fillOpacity={0.9} fontSize={12}>
            {width > 118 ? `${formatMoney(value)} · ${share}` : share}
          </text>
        </>
      )}
    </g>
  )
}
