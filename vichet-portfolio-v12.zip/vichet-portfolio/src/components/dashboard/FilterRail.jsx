import { cn } from '@/utils/cn'
import styles from './FilterRail.module.css'

function FilterGroup({ title, options, selected, onToggle }) {
  return (
    <fieldset className={styles.group}>
      <legend className={styles.legend}>{title}</legend>
      <div className={styles.chips}>
        {options.map((option) => {
          const on = selected.includes(option)
          return (
            <button
              key={option}
              type="button"
              className={cn(styles.chip, on && styles.on)}
              aria-pressed={on}
              onClick={() => onToggle(option)}
            >
              {option}
            </button>
          )
        })}
      </div>
    </fieldset>
  )
}

/** Multi-select "slicers" like the Region and Brand lists in the Power BI report. */
export default function FilterRail({ regions, brands, selected, onToggle, onClear, count, total }) {
  const active = selected.regions.length + selected.brands.length > 0

  return (
    <aside className={styles.rail} aria-label="Dashboard filters">
      <FilterGroup
        title="Region"
        options={regions}
        selected={selected.regions}
        onToggle={(v) => onToggle('regions', v)}
      />
      <FilterGroup
        title="Brand"
        options={brands}
        selected={selected.brands}
        onToggle={(v) => onToggle('brands', v)}
      />
      <div className={styles.footer}>
        <span className={styles.count} aria-live="polite">
          {count} of {total} records
        </span>
        <button type="button" className={styles.clear} onClick={onClear} disabled={!active}>
          Clear filters
        </button>
      </div>
    </aside>
  )
}
