import { useCountUp } from '@/hooks'
import styles from './Gauge.module.css'

const ARC = 'M 30 100 A 70 70 0 0 1 170 100'

/**
 * Half-circle gauge. The tick at the top marks the benchmark (the all-data average),
 * so the needle position shows whether the current selection is above or below it.
 */
export default function Gauge({ label, value, max, benchmark, format }) {
  const animated = useCountUp(value)
  const percent = Math.min(Math.max(value / max, 0), 1) * 100
  const benchPercent = Math.min(Math.max(benchmark / max, 0), 1) * 100
  // Position the benchmark tick along the arc.
  const angle = Math.PI * (1 - benchPercent / 100)
  const tick = (r) => [100 + r * Math.cos(angle), 100 - r * Math.sin(angle)]
  const [x1, y1] = tick(60)
  const [x2, y2] = tick(80)

  return (
    <div
      className={styles.gauge}
      role="img"
      aria-label={`${label}: ${format(value)}. Overall average is ${format(benchmark)}.`}
    >
      <span className={styles.label}>{label}</span>
      <svg viewBox="0 0 200 118" aria-hidden="true">
        <path className={styles.track} d={ARC} pathLength="100" />
        <path
          className={styles.fill}
          d={ARC}
          pathLength="100"
          style={{ strokeDasharray: `${percent} 100` }}
        />
        <line className={styles.tick} x1={x1} y1={y1} x2={x2} y2={y2} />
        <text className={styles.value} x="100" y="92" textAnchor="middle">
          {format(animated)}
        </text>
        <text className={styles.limit} x="30" y="116" textAnchor="middle">
          {format(0)}
        </text>
        <text className={styles.limit} x="170" y="116" textAnchor="middle">
          {format(max)}
        </text>
      </svg>
    </div>
  )
}
