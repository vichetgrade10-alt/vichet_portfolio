import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  LabelList,
  Legend,
  Line,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import {
  brandRegionMatrix,
  brandShare,
  buildInsights,
  modelRanking,
  monthlyTotals,
  vehicleTypeStats,
} from '@/utils/evAnalytics'
import {
  formatCompact,
  formatInt,
  formatMoney,
  formatMoneyExact,
  formatPercent,
} from '@/utils/format'
import { ACCENT, SECONDARY } from './palette'
import ChartCard from './ChartCard'
import ChartTooltip from './ChartTooltip'
import Gauge from './Gauge'
import Heatmap from './Heatmap'
import KpiCard from './KpiCard'
import styles from './Tabs.module.css'

const H = 270

function ModelBars({ data, color }) {
  return (
    <ResponsiveContainer width="100%" height={230}>
      <BarChart data={data} layout="vertical" margin={{ top: 4, right: 52, bottom: 0, left: 0 }}>
        <XAxis type="number" hide />
        <YAxis type="category" dataKey="name" width={84} tickLine={false} axisLine={false} />
        <Tooltip cursor={{ fill: 'transparent' }} content={<ChartTooltip format={formatInt} />} />
        <Bar dataKey="value" name="Units sold" fill={color} radius={[0, 5, 5, 0]} barSize={20}>
          <LabelList dataKey="value" position="right" formatter={formatInt} />
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  )
}

export default function OverviewTab({ rows, kpis, benchmark, brandColor }) {
  const monthly = monthlyTotals(rows)
  const vehicles = vehicleTypeStats(rows)
  const brands = brandShare(rows)
  const { top, worst } = modelRanking(rows)
  const heat = brandRegionMatrix(rows)
  const insights = buildInsights(rows)

  return (
    <div className={styles.grid}>
      <div className={styles.kpis}>
        <KpiCard
          label="Total revenue"
          value={kpis.revenue}
          format={formatMoney}
          hint="Sum of all sales"
        />
        <KpiCard label="Units sold" value={kpis.units} format={formatInt} hint="EVs delivered" />
        <KpiCard
          label="Average discount"
          value={kpis.avgDiscount}
          format={(n) => formatPercent(n, 1)}
          hint="Mean across records"
        />
        <KpiCard
          label="Top selling model"
          text={kpis.topModel}
          value={kpis.topModelUnits}
          hint={`${formatInt(kpis.topModelUnits)} units`}
        />
        <Gauge
          label="Revenue per unit"
          value={kpis.revenuePerUnit}
          max={benchmark.revenuePerUnit * 2}
          benchmark={benchmark.revenuePerUnit}
          format={formatMoneyExact}
        />
      </div>

      <ChartCard title="Monthly revenue" subtitle="2023, all selected sales" span={7}>
        <ResponsiveContainer width="100%" height={H + 70}>
          <AreaChart data={monthly} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
            <defs>
              <linearGradient id="revFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={ACCENT} stopOpacity={0.4} />
                <stop offset="100%" stopColor={ACCENT} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} />
            <XAxis dataKey="month" tickLine={false} axisLine={false} />
            <YAxis tickFormatter={formatMoney} tickLine={false} axisLine={false} width={56} />
            <Tooltip content={<ChartTooltip format={formatMoney} />} />
            <Area
              type="monotone"
              dataKey="revenue"
              name="Revenue"
              stroke={ACCENT}
              strokeWidth={2.5}
              fill="url(#revFill)"
              activeDot={{ r: 5 }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="Brand market share" subtitle="Share of units sold" span={5}>
        <div className={styles.donut}>
          <ResponsiveContainer width="100%" height={H}>
            <PieChart>
              <Tooltip
                content={
                  <ChartTooltip
                    format={(v) => `${formatInt(v)} units`}
                    title={(_, p) => p[0].name}
                  />
                }
              />
              <Pie
                data={brands}
                dataKey="value"
                nameKey="name"
                innerRadius="58%"
                outerRadius="92%"
                paddingAngle={2}
                stroke="none"
              >
                {brands.map((b) => (
                  <Cell key={b.name} fill={brandColor(b.name)} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className={styles.donutCenter} aria-hidden="true">
            <strong>{formatCompact(kpis.units)}</strong>
            <span>units</span>
          </div>
        </div>
        <ul className={styles.legend}>
          {brands.slice(0, 9).map((b) => (
            <li key={b.name}>
              <i style={{ background: brandColor(b.name) }} />
              {b.name} <b>{formatPercent(b.share, 1)}</b>
            </li>
          ))}
        </ul>
      </ChartCard>

      <ChartCard
        title="Vehicle type popularity"
        subtitle="Revenue (bars) and units sold (line)"
        span={7}
      >
        <ResponsiveContainer width="100%" height={H}>
          <ComposedChart data={vehicles} margin={{ top: 8, right: 0, bottom: 0, left: 0 }}>
            <CartesianGrid vertical={false} />
            <XAxis dataKey="type" tickLine={false} axisLine={false} />
            <YAxis
              yAxisId="left"
              tickFormatter={formatMoney}
              tickLine={false}
              axisLine={false}
              width={56}
            />
            <YAxis
              yAxisId="right"
              orientation="right"
              tickFormatter={formatCompact}
              tickLine={false}
              axisLine={false}
              width={44}
            />
            <Tooltip
              content={
                <ChartTooltip
                  format={(v, item) => (item.dataKey === 'revenue' ? formatMoney(v) : formatInt(v))}
                />
              }
            />
            <Legend iconType="circle" />
            <Bar
              yAxisId="left"
              dataKey="revenue"
              name="Revenue"
              fill={SECONDARY}
              radius={[5, 5, 0, 0]}
            />
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="units"
              name="Units sold"
              stroke={ACCENT}
              strokeWidth={2.5}
              dot={{ r: 4, fill: ACCENT }}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="Key takeaways" subtitle="Updates with your filters" span={5}>
        <ul className={styles.insights}>
          {insights.map((item) => (
            <li key={item.label}>
              <span>{item.label}</span>
              {item.text}
            </li>
          ))}
        </ul>
      </ChartCard>

      <ChartCard title="Top selling models" subtitle="Units sold" span={6}>
        <ModelBars data={top} color={SECONDARY} />
      </ChartCard>
      <ChartCard title="Worst selling models" subtitle="Units sold" span={6}>
        <ModelBars data={worst} color={ACCENT} />
      </ChartCard>

      <ChartCard title="Revenue by brand and region" subtitle="Darker = more revenue" span={12}>
        <Heatmap {...heat} />
      </ChartCard>
    </div>
  )
}
