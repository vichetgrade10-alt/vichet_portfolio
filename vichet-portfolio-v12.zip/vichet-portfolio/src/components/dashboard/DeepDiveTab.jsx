import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  LabelList,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Scatter,
  ScatterChart,
  Tooltip,
  Treemap,
  XAxis,
  YAxis,
  ZAxis,
} from 'recharts'
import {
  batteryByCharging,
  batteryScatter,
  monthlyUnitsByRegion,
  revenuePerUnitByModel,
  segmentRevenue,
  vehicleTypeStats,
} from '@/utils/evAnalytics'
import {
  formatCompact,
  formatInt,
  formatMoney,
  formatMoneyExact,
  formatPercent,
} from '@/utils/format'
import { ACCENT, SECONDARY } from './palette'
import ChartCard from './ChartCard'
import ChartTooltip from './ChartTooltip'
import TreemapNode from './TreemapNode'
import styles from './Tabs.module.css'

const H = 280

/** Percent label drawn inside each pie slice (skipped for slivers that are too small to read). */
function sliceLabel({ cx, cy, midAngle, innerRadius, outerRadius, percent }) {
  if (percent < 0.06) return null
  const radian = Math.PI / 180
  const r = innerRadius + (outerRadius - innerRadius) * 0.62
  return (
    <text
      x={cx + r * Math.cos(-midAngle * radian)}
      y={cy + r * Math.sin(-midAngle * radian)}
      fill="#fff"
      fontSize={12}
      fontWeight={800}
      textAnchor="middle"
      dominantBaseline="central"
    >
      {formatPercent(percent * 100, 0)}
    </text>
  )
}

export default function DeepDiveTab({ rows, regionColor, vehicleColor, segmentColor }) {
  const segments = segmentRevenue(rows)
  const segmentTotal = segments.reduce((t, s) => t + s.value, 0)
  const { data: regionData, regions } = monthlyUnitsByRegion(rows)
  const vehicles = vehicleTypeStats(rows)
  const scatter = batteryScatter(rows)
  const battery = batteryByCharging(rows)
  const priceByModel = revenuePerUnitByModel(rows)
  const tallHeight = Math.max(H, priceByModel.length * 24 + 24) // keeps both cards in the row level

  return (
    <div className={styles.grid}>
      <ChartCard title="Customer segment breakdown" subtitle="Share of revenue" span={5}>
        <ResponsiveContainer width="100%" height={H}>
          <Treemap
            data={segments.map((s) => ({ name: s.name, size: s.value }))}
            dataKey="size"
            nameKey="name"
            content={<TreemapNode colorOf={segmentColor} total={segmentTotal} />}
            isAnimationActive
          >
            <Tooltip
              content={<ChartTooltip format={formatMoney} title={(_, p) => p[0]?.payload?.name} />}
            />
          </Treemap>
        </ResponsiveContainer>
        <ul className={styles.legend}>
          {segments.map((s) => (
            <li key={s.name}>
              <i style={{ background: segmentColor(s.name) }} />
              {s.name} <b>{formatPercent((s.value / segmentTotal) * 100, 0)}</b>
            </li>
          ))}
        </ul>
      </ChartCard>

      <ChartCard title="Monthly units sold by region" subtitle="Stacked, 2023" span={7}>
        <ResponsiveContainer width="100%" height={H}>
          <AreaChart data={regionData} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
            <CartesianGrid vertical={false} />
            <XAxis dataKey="month" tickLine={false} axisLine={false} />
            <YAxis tickFormatter={formatCompact} tickLine={false} axisLine={false} width={44} />
            <Tooltip content={<ChartTooltip format={formatInt} />} />
            <Legend iconType="circle" />
            {regions.map((region) => (
              <Area
                key={region}
                type="monotone"
                dataKey={region}
                stackId="units"
                stroke={regionColor(region)}
                fill={regionColor(region)}
                fillOpacity={0.75}
              />
            ))}
          </AreaChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="Units sold by vehicle type" subtitle="Share of units" span={4}>
        <ResponsiveContainer width="100%" height={H}>
          <PieChart>
            <Tooltip content={<ChartTooltip format={formatInt} title={(_, p) => p[0].name} />} />
            <Pie
              data={vehicles}
              dataKey="units"
              nameKey="type"
              outerRadius="88%"
              label={sliceLabel}
              labelLine={false}
              stroke="var(--card-solid)"
              strokeWidth={2}
            >
              {vehicles.map((v) => (
                <Cell key={v.type} fill={vehicleColor(v.type)} />
              ))}
            </Pie>
            <Legend iconType="circle" />
          </PieChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard
        title="Revenue by battery capacity"
        subtitle="Each dot is a sales record; bigger = more units · log scale"
        span={8}
      >
        <ResponsiveContainer width="100%" height={H}>
          <ScatterChart margin={{ top: 8, right: 12, bottom: 4, left: 0 }}>
            <CartesianGrid />
            <XAxis
              type="number"
              dataKey="battery"
              name="Battery"
              unit=" kWh"
              domain={[40, 100]}
              tickLine={false}
            />
            <YAxis
              type="number"
              dataKey="revenue"
              name="Revenue"
              scale="log"
              domain={[500000, 40000000]}
              ticks={[1e6, 2e6, 5e6, 1e7, 2e7]}
              allowDataOverflow
              tickFormatter={formatMoney}
              tickLine={false}
              axisLine={false}
              width={56}
            />
            <ZAxis type="number" dataKey="units" range={[24, 150]} />
            <Tooltip
              cursor={{ strokeDasharray: '4 4' }}
              content={({ active, payload }) => {
                if (!active || !payload?.length) return null
                const p = payload[0].payload
                return (
                  <ChartTooltip
                    active
                    title={() => p.type}
                    payload={[
                      { name: 'Battery', value: `${p.battery} kWh`, color: vehicleColor(p.type) },
                      {
                        name: 'Revenue',
                        value: formatMoneyExact(p.revenue),
                        color: vehicleColor(p.type),
                      },
                      {
                        name: 'Units sold',
                        value: formatInt(p.units),
                        color: vehicleColor(p.type),
                      },
                    ]}
                  />
                )
              }}
            />
            <Legend iconType="circle" />
            {scatter.map((s) => (
              <Scatter
                key={s.name}
                name={s.name}
                data={s.points}
                fill={vehicleColor(s.name)}
                fillOpacity={0.6}
              />
            ))}
          </ScatterChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard
        title="Average battery capacity by fast charging"
        subtitle="kWh, per vehicle type"
        span={6}
      >
        <ResponsiveContainer width="100%" height={tallHeight}>
          <BarChart data={battery} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
            <CartesianGrid vertical={false} />
            <XAxis dataKey="type" tickLine={false} axisLine={false} />
            <YAxis tickLine={false} axisLine={false} width={36} unit="" />
            <Tooltip
              cursor={{ fill: 'transparent' }}
              content={<ChartTooltip format={(v) => `${v.toFixed(1)} kWh`} />}
            />
            <Legend iconType="circle" />
            <Bar dataKey="Fast charging" fill={ACCENT} radius={[4, 4, 0, 0]} />
            <Bar dataKey="No fast charging" fill={SECONDARY} radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="Revenue per unit by model" subtitle="Average price point" span={6}>
        <ResponsiveContainer width="100%" height={tallHeight}>
          <BarChart
            data={priceByModel}
            layout="vertical"
            margin={{ top: 0, right: 64, bottom: 0, left: 0 }}
          >
            <XAxis type="number" hide />
            <YAxis
              type="category"
              dataKey="name"
              width={84}
              tickLine={false}
              axisLine={false}
              interval={0}
            />
            <Tooltip
              cursor={{ fill: 'transparent' }}
              content={<ChartTooltip format={formatMoneyExact} />}
            />
            <Bar
              dataKey="value"
              name="Revenue per unit"
              fill={SECONDARY}
              radius={[0, 4, 4, 0]}
              barSize={14}
            >
              <LabelList dataKey="value" position="right" formatter={formatMoneyExact} />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  )
}
