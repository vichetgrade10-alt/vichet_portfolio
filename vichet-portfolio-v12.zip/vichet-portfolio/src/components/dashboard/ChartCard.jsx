import { cn } from '@/utils/cn'
import styles from './ChartCard.module.css'

/** White panel with a title - the container every chart sits in. `span` = grid columns (of 12). */
export default function ChartCard({ title, subtitle, span = 6, className, children }) {
  return (
    <section className={cn(styles.card, className)} style={{ '--span': span }}>
      <header className={styles.header}>
        <h3 className={styles.title}>{title}</h3>
        {subtitle && <p className={styles.subtitle}>{subtitle}</p>}
      </header>
      <div className={styles.body}>{children}</div>
    </section>
  )
}
