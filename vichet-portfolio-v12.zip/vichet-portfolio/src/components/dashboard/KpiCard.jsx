import { useCountUp } from '@/hooks'
import styles from './KpiCard.module.css'

/** Big-number tile. Numeric values count up/down smoothly when the filters change. */
export default function KpiCard({ label, value, format, hint, text }) {
  const animated = useCountUp(typeof value === 'number' ? value : 0)

  return (
    <div className={styles.card}>
      <span className={styles.label}>{label}</span>
      <strong className={styles.value}>{text ?? format(animated)}</strong>
      {hint && <span className={styles.hint}>{hint}</span>}
    </div>
  )
}
