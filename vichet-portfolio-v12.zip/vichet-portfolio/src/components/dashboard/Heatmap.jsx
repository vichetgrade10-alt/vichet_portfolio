import { formatMoney } from '@/utils/format'
import styles from './Heatmap.module.css'

/** Brand × Region revenue grid - darker red = more revenue (the pivot table in the Power BI report). */
export default function Heatmap({ regions, matrix, max }) {
  return (
    <div
      className={styles.scroll}
      tabIndex={0}
      role="region"
      aria-label="Revenue by brand and region"
    >
      <table className={styles.table}>
        <thead>
          <tr>
            <th scope="col">Brand</th>
            {regions.map((r) => (
              <th key={r} scope="col">
                {r}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {matrix.map(({ brand, values }) => (
            <tr key={brand}>
              <th scope="row">{brand}</th>
              {values.map((v, i) => {
                const intensity = max ? v / max : 0
                return (
                  <td
                    key={regions[i]}
                    className={styles.cell}
                    data-strong={intensity > 0.55}
                    style={{ '--v': intensity }}
                    title={`${brand} · ${regions[i]}: ${formatMoney(v)}`}
                  >
                    {v ? formatMoney(v) : '-'}
                  </td>
                )
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
