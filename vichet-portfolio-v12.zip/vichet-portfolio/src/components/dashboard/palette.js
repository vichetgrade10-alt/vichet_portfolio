/** Categorical chart colours - mid-tones that stay readable on both the light and dark theme. */
export const PALETTE = [
  '#c8102e', // red (brand)
  '#3b6fd4', // blue
  '#f2a900', // amber
  '#13a89e', // teal
  '#8b6cf6', // violet
  '#e8618c', // pink
  '#6b7a99', // slate
  '#43b04a', // green
  '#38a3e8', // sky
]

export const ACCENT = PALETTE[0]
export const SECONDARY = PALETTE[1]

/**
 * Builds a function that always returns the same colour for the same category,
 * even when filters remove other categories (so "Asia" never changes colour).
 */
export function createColorScale(allValues) {
  const order = new Map(allValues.map((value, i) => [value, i]))
  return (value) => PALETTE[(order.get(value) ?? 0) % PALETTE.length]
}
