import styles from './ChartTooltip.module.css'

/**
 * Shared hover tooltip for every chart.
 *   format(value, item) → string for each row
 *   title(label, payload) → optional heading override
 */
export default function ChartTooltip({ active, payload, label, format = String, title }) {
  if (!active || !payload?.length) return null
  const heading = title ? title(label, payload) : label

  return (
    <div className={styles.tooltip}>
      {heading && <div className={styles.heading}>{heading}</div>}
      {payload
        .filter((item) => item.value !== undefined && item.value !== null)
        .map((item, i) => (
          <div key={`${item.name}-${i}`} className={styles.row}>
            <span
              className={styles.swatch}
              style={{ background: item.color ?? item.payload?.fill ?? item.fill }}
            />
            <span className={styles.name}>{item.name}</span>
            <strong>{format(item.value, item)}</strong>
          </div>
        ))}
    </div>
  )
}
